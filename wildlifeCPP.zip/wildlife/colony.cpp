#include "colony.h"

void Colony::xDies(unsigned int x) {
    if(x >= _animalCount)
        _animalCount = 0;
    else
        _animalCount -= x;
}
