#include <iostream>
#include <fstream>
#include <time.h>
#include <stdlib.h>

#include "tundra.h"

Tundra::~Tundra() {
    for(Colony* c : _colonies)
        delete c;
}

void Tundra::populate(std::string input) {
    std::ifstream f(input);
    if(f.fail()) {
        std::cout<<"File name incorrect. Exiting..."<< std::endl;
        return;
    }
    f>>_preyC>>_predC;
    std::string name;
    char spec;
    unsigned int num;
    _colonies.resize(_predC + _preyC);
    for(unsigned int i = 0; i <_preyC + _predC; ++i){
        f>>name>>spec>>num;
        switch(spec) {
            case 'h': _colonies[i] = new Colony(name, spec, num, SnowOwl::instance()); break;
            case 's': _colonies[i] = new Colony(name, spec, num, ArcticFox::instance()); break;
            case 'f': _colonies[i] = new Colony(name, spec, num, Wolf::instance()); break;
            case 'l': _colonies[i] = new Colony(name, spec, num, Lemming::instance()); _startPrey += num; break;
            case 'n': _colonies[i] = new Colony(name, spec, num, ArcticHare::instance()); _startPrey += num; break;
            case 'u': _colonies[i] = new Colony(name, spec, num, Gopher::instance()); _startPrey += num; break;
        }
    }
    if(!_test) std::cout<<"starting stats"<<std::endl;
    if(!_test) print();
}

void Tundra::reproduce() {
    for(unsigned int i = 0; i < _preyC; ++i) {
        if(_colonies[i]->isDead() == false) {
            if((_round % _colonies[i]->getAnimal()->getDetails()[1]) == 0) {
                double t = _colonies[i]->getAnimal()->getDetails()[2] / 100.0;
                double born = _colonies[i]->getSize() * t;
                unsigned int iBorn = static_cast<unsigned int>(born);
                if(!_test) std::cout<<"in "<<_colonies[i]->getName()<<' '<<iBorn<<" animals were born."<<std::endl;
                _colonies[i]->xBorn(iBorn);
            }
        }
    }
    for(unsigned int j = _preyC; j < _preyC + _predC; ++j){
        if(_colonies[j]->isDead() == false){
            if((_round % _colonies[j]->getAnimal()->getDetails()[1]) == 0){
                _colonies[j]->xBorn((_colonies[j]->getSize() / _colonies[j]->getAnimal()->getDetails()[2]) * _colonies[j]->getAnimal()->getDetails()[3]);
                if(!_test) std::cout<<"in "<<_colonies[j]->getName()<<' '<<(_colonies[j]->getSize() / _colonies[j]->getAnimal()->getDetails()[2]) * _colonies[j]->getAnimal()->getDetails()[3]<<" animals were born."<<std::endl;
            }
        }
    }
}

void Tundra::hunt() {
    srand (time(NULL));
    for(unsigned int i = _preyC ; i < _preyC + _predC; ++i) {
        if(allDead()){
            if(!_test) std::cout<<_colonies[i]->getName()<<" colony has lost "<<_colonies[i]->getSize() / _colonies[i]->getAnimal()->getDetails()[0]<<" members because it has nothing to hunt."<<std::endl;
            _colonies[i]->xDies(_colonies[i]->getSize() / _colonies[i]->getAnimal()->getDetails()[0]);
        }
        else {
            int r;
            if(!_test) {
                r = rand() % _preyC;
                while(_colonies[r]->isDead()) {
                    r = rand() % _preyC;
                }
            }
            else {
                r = 0;
                while(_colonies[r]->isDead()) r++;
            }
            if(_colonies[r]->isDead() == false) {
                unsigned int dies = _colonies[i]->getSize() * _colonies[r]->getAnimal()->getDetails()[0];
                if(dies > _colonies[r]->getSize()) {
                    dies = _colonies[r]->getSize();
                    if(!_test) std::cout<<_colonies[i]->getName()<<" has lost "<<(_colonies[i]->getSize() / _colonies[i]->getAnimal()->getDetails()[0])<<" members and has hunted "<<dies<<" of "<<_colonies[r]->getName()<<std::endl;
                    _colonies[i]->xDies(_colonies[i]->getSize() / _colonies[i]->getAnimal()->getDetails()[0]);
                }
                else
                    if(!_test) std::cout<<_colonies[i]->getName()<<" has hunted "<<dies<<" of "<<_colonies[r]->getName()<<std::endl;
                _colonies[r]->xDies(dies);
            }
        }
    }
}

void Tundra::migrate() {
    for(unsigned int i = 0; i < _preyC ; ++i) {
        if(_colonies[i]->isDead() == false) {
            if(_colonies[i]->getSize() > _colonies[i]->getAnimal()->getDetails()[3]) {
                _colonies[i]->setSize(_colonies[i]->getAnimal()->getDetails()[4]);
                if(!_test) std::cout<<_colonies[i]->getName()<<" has migrated"<<std::endl;
            }
        }
    }
}

void Tundra::print() const {
    std::cout<<std::endl;
    for(Colony* c : _colonies) {
        std::cout<<c->getName()<<' '<<c->getSpc()<<' '<<c->getSize()<<std::endl;
    }
    std::cout<<std::endl;
}

bool Tundra::allDead() const {
    bool b = true;
    for(unsigned int i = 0; i < _preyC; ++i) {
        b = b && (_colonies[i]->getSize() == 0);
    }
    return b;
}

bool Tundra::endSim() const {
    unsigned int currPrey = 0;
    for(unsigned int i = 0; i < _preyC; ++i) {
        currPrey += _colonies[i]->getSize();
    }
    bool c = (currPrey >= _startPrey * 4) ? true : false;
    return allDead() || c;
}

void Tundra::round() {
    while(endSim() == false) {
        _round++;
        if(!_test) std::cout<<"Round: "<<_round<<std::endl<<std::endl;
        reproduce();
        hunt();
        migrate();
        if(!_test) print();
        if(endSim() == false) {
            if(!_test) std::cout<<std::endl<<"press enter to continue"<<std::endl<<std::endl;
            if(!_test) std::cin.ignore();
        }
    }
    if(!_test) {
        if(allDead())
            std::cout<<"All prey animal colonies have died. Simulation over..."<<std::endl;
        else
            std::cout<<"The number of prey animals has quadrupled since the beginning. Simulation over..."<<std::endl;
    }
}
