#include <iostream>


#include "tundra.h"
#include "colony.h"
#include "animal.h"

using namespace std;

void destroyInstances() {
    SnowOwl::destroy();
    ArcticFox::destroy();
    Wolf::destroy();
    Lemming::destroy();
    ArcticHare::destroy();
    Gopher::destroy();
}


//#define NORMAL_MODE
#ifdef NORMAL_MODE

bool Tundra::_test = false;

int main()
{
    Tundra* tundra = new Tundra();
    tundra->populate("input.txt");
    tundra->round();
    delete(tundra);
    destroyInstances();
    return 0;
}


#else
#define CATCH_CONFIG_MAIN
#include "catch.hpp"

bool Tundra::_test = true;

TEST_CASE("no colonies", "input1.txt") {

    Tundra* tundra = new Tundra();
    tundra->populate("input1.txt");
    tundra->round();
    CHECK(tundra->getRound() == 0);
    CHECK(tundra->allDead());
    CHECK(tundra->endSim());
    destroyInstances();
    delete(tundra);
}

TEST_CASE("one colony", "input2.txt") {

    SECTION("one prey colony") {

        Tundra* tundra = new Tundra();
        tundra->populate("input2_1.txt");
        tundra->round();
        CHECK(tundra->getRound() == 4);
        CHECK_FALSE(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);

        tundra = new Tundra();
        tundra->populate("input2_2.txt");
        tundra->round();
        CHECK(tundra->getRound() == 8);
        CHECK_FALSE(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);

        tundra = new Tundra();
        tundra->populate("input2_3.txt");
        tundra->round();
        CHECK(tundra->getRound() == 8);
        CHECK_FALSE(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);
        destroyInstances();
    }

    SECTION("one prey colony") {

        Tundra* tundra = new Tundra();
        tundra->populate("input2_4.txt");
        tundra->round();
        CHECK(tundra->getRound() == 0);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);

        tundra = new Tundra();
        tundra->populate("input2_5.txt");
        tundra->round();
        CHECK(tundra->getRound() == 0);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);

        tundra = new Tundra();
        tundra->populate("input2_6.txt");
        tundra->round();
        CHECK(tundra->getRound() == 0);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);
        destroyInstances();
    }

}

TEST_CASE("two colonies of the same type", "input3_*.txt") {

    SECTION("one prey colonies") {

        Tundra* tundra = new Tundra();
        tundra->populate("input3_1.txt");
        tundra->round();
        CHECK(tundra->getRound() == 6);
        CHECK_FALSE(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);

        tundra = new Tundra();
        tundra->populate("input3_2.txt");
        tundra->round();
        CHECK(tundra->getRound() == 6);
        CHECK_FALSE(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);

        tundra = new Tundra();
        tundra->populate("input3_3.txt");
        tundra->round();
        CHECK(tundra->getRound() == 8);
        CHECK_FALSE(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);
        destroyInstances();
    }

    SECTION("two prey colonies") {

        Tundra* tundra = new Tundra();
        tundra->populate("input3_4.txt");
        tundra->round();
        CHECK(tundra->getRound() == 0);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);

        tundra = new Tundra();
        tundra->populate("input3_5.txt");
        tundra->round();
        CHECK(tundra->getRound() == 0);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);

        tundra = new Tundra();
        tundra->populate("input3_6.txt");
        tundra->round();
        CHECK(tundra->getRound() == 0);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);
        destroyInstances();
    }
}

TEST_CASE("two colonies of the different types", "input4_*.txt") {

    Tundra* tundra = new Tundra();
    tundra->populate("input4_1.txt");
    tundra->round();
    CHECK(tundra->getRound() == 2);
    CHECK(tundra->allDead());
    CHECK(tundra->endSim());
    delete(tundra);

    tundra = new Tundra();
    tundra->populate("input4_2.txt");
    tundra->round();
    CHECK(tundra->getRound() == 4);
    CHECK(tundra->allDead());
    CHECK(tundra->endSim());
    delete(tundra);

    tundra = new Tundra();
    tundra->populate("input4_3.txt");
    tundra->round();
    CHECK(tundra->getRound() == 2);
    CHECK(tundra->allDead());
    CHECK(tundra->endSim());
    delete(tundra);
    destroyInstances();
}

TEST_CASE("two of one tpye, one colony of the other type", "input5_*.txt") {

    SECTION("two prey, one predator colony") {

        Tundra* tundra = new Tundra();
        tundra->populate("input5_1.txt");
        tundra->round();
        CHECK(tundra->getRound() == 5);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);

        tundra = new Tundra();
        tundra->populate("input5_2.txt");
        tundra->round();
        CHECK(tundra->getRound() == 3);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);

        tundra = new Tundra();
        tundra->populate("input5_3.txt");
        tundra->round();
        CHECK(tundra->getRound() == 9);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);
        destroyInstances();
    }
    SECTION("one prey, two predator colonies") {

        Tundra* tundra = new Tundra();
        tundra->populate("input5_4.txt");
        tundra->round();
        CHECK(tundra->getRound() == 2);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);

        tundra = new Tundra();
        tundra->populate("input5_5.txt");
        tundra->round();
        CHECK(tundra->getRound() == 4);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);

        tundra = new Tundra();
        tundra->populate("input5_6.txt");
        tundra->round();
        CHECK(tundra->getRound() == 3);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);
        destroyInstances();
    }
}

TEST_CASE("multiple of each colony", "input6_*.txt") {

    SECTION("two of each colony") {

        Tundra* tundra = new Tundra();
        tundra->populate("input6_1.txt");
        tundra->round();
        CHECK(tundra->getRound() == 4);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);
        destroyInstances();
    }

    SECTION("three of each colony") {

        Tundra* tundra = new Tundra();
        tundra->populate("input6_2.txt");
        tundra->round();
        CHECK(tundra->getRound() == 2);
        CHECK(tundra->allDead());
        CHECK(tundra->endSim());
        delete(tundra);
        destroyInstances();
    }
}

TEST_CASE("reproduce", "input7_*.txt") {
    SECTION("not time to reproduce") {
        Tundra* tundra = new Tundra();
        tundra->populate("input7_1.txt");
        tundra->setRound(1);
        tundra->reproduce();
        vector<Colony*> test = tundra->getColonies();
        CHECK(test[0]->getSize() == 20);
        CHECK(test[1]->getSize() == 20);
        delete(tundra);
        destroyInstances();
    }

    SECTION("time to reproduce") {
        Tundra* tundra = new Tundra();
        tundra->populate("input7_2.txt");
        tundra->setRound(8);
        tundra->reproduce();
        vector<Colony*> test = tundra->getColonies();
        CHECK(test[0]->getSize() == 40);
        CHECK(test[1]->getSize() == 30);
        delete(tundra);
        destroyInstances();
    }

}

TEST_CASE("hunt", "input8_*.txt") {
    SECTION("unsuccessful hunt") {
        Tundra* tundra = new Tundra();
        tundra->populate("input8_1.txt");
        tundra->setRound(1);
        tundra->hunt();
        vector<Colony*> test = tundra->getColonies();
        CHECK(test[0]->getSize() == 0);
        CHECK(test[1]->getSize() == 15);
        delete(tundra);
        destroyInstances();
    }

    SECTION("successful hunt") {
        Tundra* tundra = new Tundra();
        tundra->populate("input8_2.txt");
        tundra->setRound(1);
        tundra->reproduce();
        vector<Colony*> test = tundra->getColonies();
        CHECK(test[0]->getSize() == 80);
        CHECK(test[1]->getSize() == 20);
        delete(tundra);
        destroyInstances();
    }
}

TEST_CASE("migrate", "input9_*.txt") {
    SECTION("no migrate") {
        Tundra* tundra = new Tundra();
        tundra->populate("input9_1.txt");
        tundra->setRound(1);
        tundra->migrate();
        vector<Colony*> test = tundra->getColonies();
        CHECK(test[0]->getSize() == 180);
        CHECK(test[1]->getSize() == 170);
        delete(tundra);
        destroyInstances();
    }

    SECTION("yes migrate") {
        Tundra* tundra = new Tundra();
        tundra->populate("input9_2.txt");
        tundra->setRound(1);
        tundra->migrate();
        vector<Colony*> test = tundra->getColonies();
        CHECK(test[0]->getSize() == 30);
        CHECK(test[1]->getSize() == 40);
        delete(tundra);
        destroyInstances();
    }
}
#endif // NORMAL_MODE
