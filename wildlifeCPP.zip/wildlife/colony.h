#ifndef COLONY_H
#define COLONY_H

#include <iostream>

#include "animal.h"

class Colony {

public:
    Colony(std::string n, char s, unsigned int ac, Animal* a) : _name(n), _species(s), _animalCount(ac), _animal(a) {}
    ~Colony() {}

    unsigned int getSize() const { return _animalCount; }
    void setSize(unsigned int x) {_animalCount = x; }
    std::string getName() const { return _name; }
    char getSpc() { return _species; }
    Animal* getAnimal() const { return _animal; }
    bool isDead() const { return _animalCount == 0; }
    void xDies(unsigned int x);
    void xBorn(unsigned int x) { _animalCount += x; }
private:
    std::string _name;
    char _species;
    unsigned int _animalCount;
    Animal* _animal;
};

#endif // COLONY_H
