#ifndef ANIMAL_H
#define ANIMAL_H

#include <vector>
#include <iostream>

class Animal{

public:
    virtual std::vector<unsigned int> getDetails() const {
        std::vector<unsigned int> details;
        return details;
    }
    virtual ~Animal() { }
};



class Predator : public Animal {

public:
    std::vector<unsigned int> getDetails() const override;

protected:
    unsigned int _nthDies;
    unsigned int _repTime;
    unsigned int _parents;
    unsigned int _offspring;
    Predator(unsigned int nth, unsigned int r, unsigned int p, unsigned int o) : _nthDies(nth), _repTime(r), _parents(p), _offspring(o) {}
};

class Prey : public Animal {

public:
    std::vector<unsigned int> getDetails() const override;

protected:
    unsigned int _huntDiv;
    unsigned int _repTime;
    unsigned int _multiplier;
    unsigned int _maxCount;
    unsigned int _defaultCount;
    Prey(unsigned int div, unsigned int t, unsigned int m, unsigned int mc, unsigned int dc) : _huntDiv(div), _repTime(t), _multiplier(m), _maxCount(mc), _defaultCount(dc) {}
};





class SnowOwl : public Predator {

public:
    static SnowOwl* instance();
    static void destroy();

private:
    SnowOwl() : Predator(4, 8, 4, 1) {}
    static SnowOwl* _instance;

};

class ArcticFox : public Predator {

public:
    static ArcticFox* instance();
    static void destroy();

private:
    ArcticFox() : Predator(4, 8, 4, 3) {}
    static ArcticFox* _instance;
};

class Wolf : public Predator {

public:
    static Wolf* instance();
    static void destroy();

private:
    Wolf() : Predator(4, 8, 4, 2) {}
    static Wolf* _instance;
};





class Lemming : public Prey {

public:
    static Lemming* instance();
    static void destroy();

private:
    Lemming() : Prey(4, 2, 100, 200, 30) {}
    static Lemming* _instance;
};

class ArcticHare : public Prey {

public:
    static ArcticHare* instance();
    static void destroy();

private:
    ArcticHare() : Prey(2, 2, 50, 100, 20) {}
    static ArcticHare* _instance;
};

class Gopher : public Prey {

public:
    static Gopher* instance();
    static void destroy();

private:
    Gopher() : Prey(2, 4, 100, 200, 40) {}
    static Gopher* _instance;

};

#endif // ANIMAL_H
