#ifndef TUNDRA_H
#define TUNDRA_H

#include <vector>

#include "colony.h"
#include "animal.h"

class Tundra {

public:
    Tundra() { }
    ~Tundra();
    void populate(std::string input);
    void round();
    void reproduce();
    void hunt();
    void migrate();
    void print() const;
    bool allDead() const;
    bool endSim() const;

    //for testing
    unsigned int getRound() const { return _round; }
    void setRound(unsigned int x) { _round = x; }
    std::vector<Colony*> getColonies() const {
        std::vector<Colony*> test;
        for(Colony* c : _colonies)
            test.push_back(c);
        return test;
         }

private:
    static bool _test;
    unsigned int _predC;
    unsigned int _preyC;
    unsigned int _startPrey = 0;
    unsigned int _round = 0;
    std::vector<Colony*> _colonies;

};

#endif // TUNDRA_H
