#include "animal.h"

#include <vector>

std::vector<unsigned int> Predator::getDetails() const {
    std::vector<unsigned int> details;
    details.push_back(_nthDies);
    details.push_back(_repTime);
    details.push_back(_parents);
    details.push_back(_offspring);
    return details;
}

std::vector<unsigned int> Prey::getDetails() const {
    std::vector<unsigned int> details;
    details.push_back(_huntDiv);
    details.push_back(_repTime);
    details.push_back(_multiplier);
    details.push_back(_maxCount);
    details.push_back(_defaultCount);
    return details;
}

SnowOwl* SnowOwl::_instance = nullptr;
SnowOwl* SnowOwl::instance()
{
    if(nullptr==_instance) _instance = new SnowOwl();
    return _instance;
}

void SnowOwl::destroy()
{
    if ( nullptr!=_instance )
    {
        delete _instance;
        _instance = nullptr;
    }
}

ArcticFox* ArcticFox::_instance = nullptr;
ArcticFox* ArcticFox::instance()
{
    if(nullptr==_instance) _instance = new ArcticFox();
    return _instance;
}

void ArcticFox::destroy()
{
    if ( nullptr!=_instance )
    {
        delete _instance;
        _instance = nullptr;
    }
}

Wolf* Wolf::_instance = nullptr;
Wolf* Wolf::instance()
{
    if(nullptr==_instance) _instance = new Wolf();
    return _instance;
}

void Wolf::destroy()
{
    if ( nullptr!=_instance )
    {
        delete _instance;
        _instance = nullptr;
    }
}

Lemming* Lemming::_instance = nullptr;
Lemming* Lemming::instance()
{
    if(nullptr==_instance) _instance = new Lemming();
    return _instance;
}

void Lemming::destroy()
{
    if ( nullptr!=_instance )
    {
        delete _instance;
        _instance = nullptr;
    }
}

ArcticHare* ArcticHare::_instance = nullptr;
ArcticHare* ArcticHare::instance()
{
    if(nullptr==_instance) _instance = new ArcticHare();
    return _instance;
}

void ArcticHare::destroy()
{
    if ( nullptr!=_instance )
    {
        delete _instance;
        _instance = nullptr;
    }
}

Gopher* Gopher::_instance = nullptr;
Gopher* Gopher::instance()
{
    if(nullptr==_instance) _instance = new Gopher();
    return _instance;
}

void Gopher::destroy()
{
    if ( nullptr!=_instance )
    {
        delete _instance;
        _instance = nullptr;
    }
}
