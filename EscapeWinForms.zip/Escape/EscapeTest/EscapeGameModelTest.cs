using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Escape.Model;
using Escape.Persistence;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace EscapeTest
{
    [TestClass]
    public class EscapeGameModelTest
    {

        private EscapeGameModel _model;
        private EscapeBoard _mockedBoard;
        private Mock<IEscapeDataAccess> _mock;

        [TestInitialize]
        public void Initialize()
        {
            _mockedBoard = new EscapeBoard(15, 0);
            for (Int32 i = 0; i < _mockedBoard.BoardSize; i++)
                for (Int32 j = 0; j < _mockedBoard.BoardSize; j++)
                {
                    _mockedBoard.SetValue(i, j, Entity.Empty);
                }
            _mockedBoard.SetValue(0, 0, Entity.Enemy);
            _mockedBoard.SetValue(0, 3, Entity.Bomb);
            _mockedBoard.SetValue(0, 5, Entity.Player);

            _mock = new Mock<IEscapeDataAccess>();
            _mock.Setup(mock => mock.LoadAsync(It.IsAny<String>()))
                .Returns(() => Task.FromResult(_mockedBoard));

            _model = new EscapeGameModel(15,_mock.Object);

            _model.BoardChanged += new EventHandler<EscapeEventArgs>(Model_BoardChanged);
            _model.TimeUpdate += new EventHandler<EscapeEventArgs>(Model_TimeUpdate);
            _model.GameOver += new EventHandler<EscapeEventArgs>(Model_GameOver);

        }

        [TestMethod]
        public void EscapeGameModelNewGameMediumTest()
        {

            Assert.AreEqual(15, _model.BoardSize);
            Assert.AreEqual(0, _model.GameTime);

            Int32 emptyFields = 0;
            for (Int32 i = 0; i < _model.BoardSize; i++)
                for (Int32 j = 0; j < _model.BoardSize; j++)
                    if (_model.Board.GetValue(i, j) == Entity.Empty)
                        emptyFields++;

            Assert.AreEqual(15*15-10, emptyFields);
        }

        [TestMethod]
        public void EscapeGameModelNewGameSmallTest()
        {
            _model.BoardSize = 11;
            _model.NewGame();

            Assert.AreEqual(11, _model.BoardSize);
            Assert.AreEqual(0, _model.GameTime);

            Int32 emptyFields = 0;
            for (Int32 i = 0; i < _model.BoardSize; i++)
                for (Int32 j = 0; j < _model.BoardSize; j++)
                    if (_model.Board.GetValue(i, j) == Entity.Empty)
                        emptyFields++;

            Assert.AreEqual(11 * 11 - 10, emptyFields);
        }

        [TestMethod]
        public void EscapeGameModelNewGameLargeTest()
        {
            _model.BoardSize = 21;
            _model.NewGame();

            Assert.AreEqual(21, _model.BoardSize);
            Assert.AreEqual(0, _model.GameTime);

            Int32 emptyFields = 0;
            for (Int32 i = 0; i < _model.BoardSize; i++)
                for (Int32 j = 0; j < _model.BoardSize; j++)
                    if (_model.Board.GetValue(i, j) == Entity.Empty)
                        emptyFields++;

            Assert.AreEqual(21 * 21 - 10, emptyFields);
        }

        [TestMethod]
        public void EscapeGameModelEnemyTurnTest()
        {

            _model.NewGame();

            Assert.AreEqual(Entity.Enemy, _model.Board[4, 0]);
            Assert.AreEqual(Entity.Enemy, _model.Board[0, 5]);
            Assert.AreEqual(0, _model.GameTime);

            _model.EnemyTurn();

            Assert.AreEqual(Entity.Enemy, _model.Board[4, 1]);
            Assert.AreEqual(Entity.Enemy, _model.Board[0, 6]);
            Assert.AreEqual(0, _model.GameTime);

            _model.EnemyTurn();

            Assert.AreEqual(Entity.Enemy, _model.Board[4, 2]);
            Assert.AreEqual(Entity.Enemy, _model.Board[0, 7]);

            _model.EnemyTurn();

            Assert.AreEqual(Entity.Enemy, _model.Board[4, 3]);
            Assert.AreEqual(Entity.Enemy, _model.Board[0, 8]);

            _model.EnemyTurn();

            Assert.AreEqual(Entity.Enemy, _model.Board[4, 4]);
            Assert.AreEqual(Entity.Enemy, _model.Board[1, 8]);

            _model.EnemyTurn();
            _model.EnemyTurn();
            _model.EnemyTurn();
            Assert.IsTrue(_model.IsGameOver);

        }

        [TestMethod]
        public void EscapeGameModelPlayerTurnTest()
        {
            _model.NewGame();

            Assert.AreEqual(Entity.Player, _model.Board[7, _model.BoardSize - 1]);

            _model.PlayerTurn(0, -1);
            Assert.AreEqual(Entity.Player, _model.Board[7, _model.BoardSize - 2]);
            Assert.AreEqual(0, _model.GameTime);

            _model.PlayerTurn(1, 0);
            Assert.AreEqual(Entity.Player, _model.Board[8, _model.BoardSize - 2]);

            _model.PlayerTurn(-1, 0);
            Assert.AreEqual(Entity.Player, _model.Board[7, _model.BoardSize - 2]);

            _model.PlayerTurn(0, 1);
            Assert.AreEqual(Entity.Player, _model.Board[7, _model.BoardSize - 1]);
            for(Int32 i = 0; i < 7; ++i)
            {
                _model.PlayerTurn(0, -1);
            }
            Assert.IsTrue(_model.Board.IsPlayerDead);
            Assert.IsTrue(_model.IsGameOver);
        }

        [TestMethod]
        public void SudokuGameModelAdvanceTimeTest()
        {
            _model.NewGame();

            Int32 time = _model.GameTime;

            _model.AdvanceTime();

            time++;

            Assert.AreEqual(time, _model.GameTime);

        }

        [TestMethod]
        public async Task SudokuGameModelLoadTest()
        {

            _model.NewGame();

            await _model.LoadGameAsync(String.Empty);

            for (Int32 i = 0; i < _model.BoardSize; i++)
                for (Int32 j = 0; j < _model.BoardSize; j++)
                {
                    Assert.AreEqual(_mockedBoard.GetValue(i, j), _model.Board.GetValue(i, j));

                }

            _mock.Verify(dataAccess => dataAccess.LoadAsync(String.Empty), Times.Once());
        }

        [TestMethod]
        public async Task SudokuGameModelSaveTest()
        {
            _model.NewGame();

            await _model.SaveGameAsync(String.Empty);

            _mock.Verify(dataAccess => dataAccess.SaveAsync(String.Empty, _model.Board), Times.Once());
        }
        private void Model_BoardChanged(Object sender, EscapeEventArgs e)
        {
            Assert.AreEqual(e.BoardSize, _model.BoardSize);
            Assert.AreEqual(e.GameTime, _model.GameTime);
            Assert.IsFalse(e.IsWon);
        }

        private void Model_TimeUpdate(Object sender, EscapeEventArgs e)
        {
            Assert.IsTrue(_model.GameTime >= 0);
            Assert.AreEqual(e.GameTime, _model.GameTime);
        }

        private void Model_GameOver(Object sender, EscapeEventArgs e)
        {
            Assert.IsTrue(_model.IsGameOver);
            Assert.AreEqual(_model.Board.IsPlayerDead || _model.Board.AreEnemiesDead, _model.IsGameOver);
            if(_mockedBoard.IsPlayerDead)
                Assert.IsFalse(e.IsWon);
            if(_mockedBoard.AreEnemiesDead)
                Assert.IsTrue(e.IsWon);
        }
    }
}
