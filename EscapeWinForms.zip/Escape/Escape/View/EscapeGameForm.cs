﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Escape.Model;
using Escape.Persistence;

namespace Escape
{
    public partial class EscapeGameForm : Form
    {

        #region Size constants

        private const Int32 BoardSizeSmall = 11;
        private const Int32 BoardSizeMedium = 15;
        private const Int32 BoardSizeLarge = 21;

        #endregion

        #region Private fields

        private IEscapeDataAccess _dataAccess;
        private Timer _timer;
        private EscapeGameModel _model;

        #endregion

        #region Constructors

        public EscapeGameForm()
        {
            InitializeComponent();
        }

        #endregion

        #region Form event handlers

        private void EscapeGameForm_Load(object sender, EventArgs e)
        {
            _dataAccess = new EscapeFileDataAccess();
            _model = new EscapeGameModel(BoardSizeMedium,_dataAccess);

            this.ClientSize = new Size(28 * _model.BoardSize, 28 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);

            _timer = new Timer();
            _timer.Interval = 1000;
            _timer.Tick += new EventHandler(Timer_Tick);
            _timer.Start();

            _model.BoardChanged += new EventHandler<EscapeEventArgs>(Model_BoardChanged);
            _model.TimeUpdate += new EventHandler<EscapeEventArgs>(Model_TimeUpdate);
            _model.GameOver += new EventHandler<EscapeEventArgs>(Model_GameOver);
        }

        private void EscapeGameForm_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.W:
                    try
                    {
                        _model.PlayerTurn(0, -1);
                    }
                    catch { }
                    break;
                case Keys.S:
                    try
                    {
                        _model.PlayerTurn(0, 1);
                    }
                    catch { }
                    break;
                case Keys.D:
                    try
                    {
                        _model.PlayerTurn(1, 0);
                    }
                    catch { }
                    break;
                case Keys.A:
                    try
                    {
                        _model.PlayerTurn(-1, 0);
                    }
                    catch { }
                    break;
            }
        }

        #endregion

        #region Menu event handlers

        private void MenuSizeSmall_Click(object sender, EventArgs e)
        {
            Boolean startTimer = _timer.Enabled;
            _timer.Stop();
            _model.BoardSize = BoardSizeSmall;
            _model.NewGame();
            this.ClientSize = new Size(28 * _model.BoardSize, 28 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);
            _statusTime.Text = "0:00:00";
            _panel.Refresh();
            if (startTimer)
                _timer.Start();
        }

        private void MenuSizeMedium_Click(object sender, EventArgs e)
        {
            Boolean startTimer = _timer.Enabled;
            _timer.Stop();
            _model.BoardSize = BoardSizeMedium;
            _model.NewGame();
            this.ClientSize = new Size(28 * _model.BoardSize, 28 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);
            _statusTime.Text = "0:00:00";
            _panel.Refresh();
            if (startTimer)
                _timer.Start();
        }

        private void MenuSizeLarge_Click(object sender, EventArgs e)
        {
            Boolean startTimer = _timer.Enabled;
            _timer.Stop();
            _model.BoardSize = BoardSizeLarge;
            _model.NewGame();
            this.ClientSize = new Size(28 * _model.BoardSize, 28 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);
            _statusTime.Text = "0:00:00";
            _panel.Refresh();
            if(startTimer)
                _timer.Start();
        }

        private void MenuPause_Click(object sender, EventArgs e)
        {
            if (_timer.Enabled)
            {
                _menuPause.Text = "Unpause";
                _timer.Stop();
                this.KeyDown -= EscapeGameForm_KeyDown;
                _menuLoad.Enabled = true;
                _menuSave.Enabled = true;
            }
            else
            {
                _menuPause.Text = "Pause";
                _timer.Start();
                this.KeyDown += EscapeGameForm_KeyDown;
                _menuLoad.Enabled = false;
                _menuSave.Enabled = false;
            }
        }

        private async void MenuLoad_Click(object sender, EventArgs e)
        {
            if (_openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    await _model.LoadGameAsync(_openFileDialog.FileName);
                }
                catch (EscapeDataException)
                {
                    MessageBox.Show("An error occured during loading.", "Escape", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private async void MenuSave_Click(object sender, EventArgs e)
        {
            if (_saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    await _model.SaveGameAsync(_saveFileDialog.FileName);
                }
                catch (EscapeDataException)
                {
                    MessageBox.Show("An error occured during saving.", "Escape", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        #endregion

        #region Model event handlers

        private void Model_TimeUpdate(Object sender, EscapeEventArgs e)
        {
            _statusTime.Text = TimeSpan.FromSeconds(e.GameTime).ToString("g");
        }

        private void Model_BoardChanged(object sender, EscapeEventArgs e)
        {
            this.ClientSize = new Size(28 * _model.BoardSize, 28 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);
            _panel.Refresh();
        }

        private void Model_GameOver(object sender, EscapeEventArgs e)
        {
            this.KeyDown -= EscapeGameForm_KeyDown;
            _timer.Stop();
            _menuSave.Enabled = false;

            switch (e.IsWon)
            {
                case true:
                    MessageBox.Show("You won! :D" + Environment.NewLine + $"You escaped the enemies in {e.GameTime} seconds.", "Escape", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    break;
                case false:
                    MessageBox.Show("You lost! ;(" + Environment.NewLine + $"The enemies caught you in {e.GameTime} seconds.", "Escape", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    break;
            }
            this.KeyDown += EscapeGameForm_KeyDown;
            _model.NewGame();
            _panel.Refresh();
            _statusTime.Text = "0:00:0";
            _timer.Start();
        }

        #endregion

        #region Panel Event handlers

        private void Panel_Paint(object sender, PaintEventArgs e)
        {
            Bitmap bitmap = new Bitmap(_panel.Width, _panel.Height);
            Graphics graphics = Graphics.FromImage(bitmap);
            graphics.Clear(Color.White);

            Int32 fieldWidth = _panel.Width / _model.BoardSize;
            Int32 fieldHeight = _panel.Height / _model.BoardSize;

            for (Int32 i = 0; i < _model.BoardSize; ++i)
            {
                for (Int32 j = 0; j < _model.BoardSize; ++j)
                {
                    switch (_model.Board[i, j])
                    {
                        case Entity.Player:
                            graphics.FillRectangle(Brushes.Green, i * fieldHeight, j * fieldWidth, fieldHeight, fieldWidth);
                            break;
                        case Entity.Enemy:
                            graphics.FillRectangle(Brushes.Red, i * fieldHeight, j * fieldWidth, fieldHeight, fieldWidth);
                            break;
                        case Entity.Bomb:
                            graphics.FillRectangle(Brushes.Black, i * fieldHeight, j * fieldWidth, fieldHeight, fieldWidth);
                            break;

                    }
                }
            }
            e.Graphics.DrawImage(bitmap, 0, 0);
        }

        #endregion

        #region Timer event handlers

        private void Timer_Tick(Object sender, EventArgs e)
        {
            _model.AdvanceTime();
            _model.EnemyTurn();
        }


        #endregion
    }
}
