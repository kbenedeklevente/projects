﻿
namespace Escape
{
    partial class EscapeGameForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._menuStrip = new System.Windows.Forms.MenuStrip();
            this._menuPause = new System.Windows.Forms.ToolStripMenuItem();
            this._menuNewGame = new System.Windows.Forms.ToolStripMenuItem();
            this._menuSizeSmall = new System.Windows.Forms.ToolStripMenuItem();
            this._menuSizeMedium = new System.Windows.Forms.ToolStripMenuItem();
            this._menuSizeLarge = new System.Windows.Forms.ToolStripMenuItem();
            this._menuSave = new System.Windows.Forms.ToolStripMenuItem();
            this._menuLoad = new System.Windows.Forms.ToolStripMenuItem();
            this._statusStrip = new System.Windows.Forms.StatusStrip();
            this._statusTimeText = new System.Windows.Forms.ToolStripStatusLabel();
            this._statusTime = new System.Windows.Forms.ToolStripStatusLabel();
            this._panel = new System.Windows.Forms.Panel();
            this._openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this._saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this._menuStrip.SuspendLayout();
            this._statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // _menuStrip
            // 
            this._menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._menuPause,
            this._menuNewGame,
            this._menuSave,
            this._menuLoad});
            this._menuStrip.Location = new System.Drawing.Point(0, 0);
            this._menuStrip.Name = "_menuStrip";
            this._menuStrip.Size = new System.Drawing.Size(589, 24);
            this._menuStrip.TabIndex = 0;
            // 
            // _menuPause
            // 
            this._menuPause.Name = "_menuPause";
            this._menuPause.Size = new System.Drawing.Size(50, 20);
            this._menuPause.Text = "Pause";
            this._menuPause.Click += new System.EventHandler(this.MenuPause_Click);
            // 
            // _menuNewGame
            // 
            this._menuNewGame.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._menuSizeSmall,
            this._menuSizeMedium,
            this._menuSizeLarge});
            this._menuNewGame.Name = "_menuNewGame";
            this._menuNewGame.Size = new System.Drawing.Size(77, 20);
            this._menuNewGame.Text = "New Game";
            // 
            // _menuSizeSmall
            // 
            this._menuSizeSmall.Name = "_menuSizeSmall";
            this._menuSizeSmall.Size = new System.Drawing.Size(141, 22);
            this._menuSizeSmall.Text = "Small size";
            this._menuSizeSmall.Click += new System.EventHandler(this.MenuSizeSmall_Click);
            // 
            // _menuSizeMedium
            // 
            this._menuSizeMedium.Name = "_menuSizeMedium";
            this._menuSizeMedium.Size = new System.Drawing.Size(141, 22);
            this._menuSizeMedium.Text = "Medium size";
            this._menuSizeMedium.Click += new System.EventHandler(this.MenuSizeMedium_Click);
            // 
            // _menuSizeLarge
            // 
            this._menuSizeLarge.Name = "_menuSizeLarge";
            this._menuSizeLarge.Size = new System.Drawing.Size(141, 22);
            this._menuSizeLarge.Text = "Large size";
            this._menuSizeLarge.Click += new System.EventHandler(this.MenuSizeLarge_Click);
            // 
            // _menuSave
            // 
            this._menuSave.Enabled = false;
            this._menuSave.Name = "_menuSave";
            this._menuSave.Size = new System.Drawing.Size(77, 20);
            this._menuSave.Text = "Save Game";
            this._menuSave.Click += new System.EventHandler(this.MenuSave_Click);
            // 
            // _menuLoad
            // 
            this._menuLoad.Enabled = false;
            this._menuLoad.Name = "_menuLoad";
            this._menuLoad.Size = new System.Drawing.Size(79, 20);
            this._menuLoad.Text = "Load Game";
            this._menuLoad.Click += new System.EventHandler(this.MenuLoad_Click);
            // 
            // _statusStrip
            // 
            this._statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._statusTimeText,
            this._statusTime});
            this._statusStrip.Location = new System.Drawing.Point(0, 291);
            this._statusStrip.Name = "_statusStrip";
            this._statusStrip.Size = new System.Drawing.Size(589, 22);
            this._statusStrip.TabIndex = 1;
            // 
            // _statusTimeText
            // 
            this._statusTimeText.Name = "_statusTimeText";
            this._statusTimeText.Size = new System.Drawing.Size(68, 17);
            this._statusTimeText.Text = "Game time:";
            // 
            // _statusTime
            // 
            this._statusTime.Name = "_statusTime";
            this._statusTime.Size = new System.Drawing.Size(43, 17);
            this._statusTime.Text = "0:00:00";
            // 
            // _panel
            // 
            this._panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._panel.Location = new System.Drawing.Point(0, 24);
            this._panel.Name = "_panel";
            this._panel.Size = new System.Drawing.Size(589, 267);
            this._panel.TabIndex = 2;
            this._panel.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel_Paint);
            // 
            // _openFileDialog
            // 
            this._openFileDialog.Filter = "Escape Board|*.stl";
            this._openFileDialog.Title = "Escape - Load game";
            // 
            // _saveFileDialog
            // 
            this._saveFileDialog.Filter = "Escape board|*.stl";
            this._saveFileDialog.Title = "Escape - Save game";
            // 
            // EscapeGameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 313);
            this.Controls.Add(this._panel);
            this.Controls.Add(this._statusStrip);
            this.Controls.Add(this._menuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this._menuStrip;
            this.MaximizeBox = false;
            this.Name = "EscapeGameForm";
            this.Text = "Escape";
            this.Load += new System.EventHandler(this.EscapeGameForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.EscapeGameForm_KeyDown);
            this._menuStrip.ResumeLayout(false);
            this._menuStrip.PerformLayout();
            this._statusStrip.ResumeLayout(false);
            this._statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip _menuStrip;
        private System.Windows.Forms.ToolStripMenuItem _menuNewGame;
        private System.Windows.Forms.ToolStripMenuItem _menuSizeSmall;
        private System.Windows.Forms.ToolStripMenuItem _menuSizeMedium;
        private System.Windows.Forms.ToolStripMenuItem _menuSizeLarge;
        private System.Windows.Forms.StatusStrip _statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel _statusTimeText;
        private System.Windows.Forms.ToolStripStatusLabel _statusTime;
        private System.Windows.Forms.ToolStripMenuItem _menuPause;
        private System.Windows.Forms.Panel _panel;
        private System.Windows.Forms.ToolStripMenuItem _menuSave;
        private System.Windows.Forms.ToolStripMenuItem _menuLoad;
        private System.Windows.Forms.OpenFileDialog _openFileDialog;
        private System.Windows.Forms.SaveFileDialog _saveFileDialog;
    }
}

