﻿using System;
using Escape.Persistence;
using System.Threading.Tasks;

namespace Escape.Model
{

    public class EscapeGameModel
    {

        #region Private fields

        private EscapeBoard _board;
        private IEscapeDataAccess _dataAccess;


        #endregion

        #region Public properties

        public Int32 GameTime { get { return _board.GameTime; } set { _board.GameTime = value; } }

        public Int32 BoardSize { get { return _board.BoardSize; } set { _board.BoardSize = value; } }

        public Boolean IsGameOver { get { return _board.IsPlayerDead || _board.AreEnemiesDead; } }

        public EscapeBoard Board { get { return _board; } }

        #endregion

        #region Events


        public event EventHandler<EscapeEventArgs> GameOver;

        public event EventHandler<EscapeEventArgs> BoardChanged;

        public event EventHandler<EscapeEventArgs> TimeUpdate;
        #endregion

        #region Constructors


        public EscapeGameModel(Int32 boardSize, IEscapeDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
            _board = new EscapeBoard(boardSize, 0);
            NewGame();
        }

        #endregion

        #region Public methods

        public void AdvanceTime()
        {
            if (IsGameOver)
                return;

            _board.GameTime++;
            OnTimeAdvanced();
        }

        public void NewGame()
        {
            _board.GenerateBoard();
        }

        public void EnemyTurn()
        {
            _board.StepEnemy();
            OnBoardChanged();
            if (_board.IsPlayerDead)
            {
                OnGameOver(false);
            }
            if (_board.AreEnemiesDead)
            {
                OnGameOver(true);
            }
        }

        public void PlayerTurn(Int32 x, Int32 y)
        {
            _board.StepPlayer(x, y);
            OnBoardChanged();
            if (_board.IsPlayerDead)
            {
                OnGameOver(false);
            }
            if (_board.AreEnemiesDead)
            {
                OnGameOver(true);
            }
        }

        public async Task LoadGameAsync(String path)
        {
            if (_dataAccess == null)
                throw new InvalidOperationException("No data access is provided.");

            _board = await _dataAccess.LoadAsync(path);

            OnBoardChanged();
            OnTimeAdvanced();
            if (_board.IsPlayerDead)
            {
                OnGameOver(false);
            }
            if (_board.AreEnemiesDead)
            {
                OnGameOver(true);
            }
        }

        public async Task SaveGameAsync(String path)
        {
            if (_dataAccess == null)
                throw new InvalidOperationException("No data access is provided.");

            await _dataAccess.SaveAsync(path, _board);
        }

        #endregion

        #region Event triggers

        private void OnGameOver(Boolean isWon)
        {
            if (GameOver != null)
                GameOver(this, new EscapeEventArgs(isWon, BoardSize, GameTime));
            GameTime = 0;
        }

        private void OnTimeAdvanced()
        {
            if (TimeUpdate != null)
                TimeUpdate(this, new EscapeEventArgs(false, BoardSize, GameTime));
        }

        private void OnBoardChanged()
        {
            if (BoardChanged != null)
                BoardChanged(this, new EscapeEventArgs(false, BoardSize, GameTime));
        }
        #endregion
    }
}
