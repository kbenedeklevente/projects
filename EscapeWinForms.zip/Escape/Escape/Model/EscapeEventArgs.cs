﻿using System;

namespace Escape.Model
{
    public class EscapeEventArgs : EventArgs
    {
        private Int32 _gameTime;
        private Int32 _boardSize;
        private Boolean _isWon;

        public Int32 GameTime { get { return _gameTime; } }

        public Int32 BoardSize { get { return _boardSize; } }

        public Boolean IsWon { get { return _isWon; } }

        public EscapeEventArgs(Boolean isWon, Int32 gameBoardSize, Int32 gameTime)
        {
            _gameTime = gameTime;
            _boardSize = gameBoardSize;
            _isWon = isWon;
        }
    }
}
