﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Escape.Persistence
{
    public class EscapeFileDataAccess : IEscapeDataAccess
    {
        public async Task<EscapeBoard> LoadAsync(String path)
        {
            try
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    String line = await reader.ReadLineAsync();
                    String[] numbers = line.Split(' ');
                    Int32 boardSize = Int32.Parse(numbers[0]);
                    Int32 gameTime = Int32.Parse(numbers[1]);
                    EscapeBoard board = new EscapeBoard(boardSize, gameTime);

                    for (Int32 i = 0; i < boardSize; i++)
                    {
                        line = await reader.ReadLineAsync();
                        numbers = line.Split(' ');

                        for (Int32 j = 0; j < boardSize; j++)
                        {
                            board.SetValue(i, j, (Entity)Int32.Parse(numbers[j]));
                        }
                    }

                    return board;
                }
            }
            catch
            {
                throw new EscapeDataException("Error occured while loading");
            }
        }

        public async Task SaveAsync(String path, EscapeBoard board)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(path))
                {
                    writer.Write(board.BoardSize);
                    await writer.WriteLineAsync(" " + board.GameTime);
                    for (Int32 i = 0; i < board.BoardSize; i++)
                    {
                        for (Int32 j = 0; j < board.BoardSize; j++)
                        {
                            await writer.WriteAsync((Int32)board[i, j] + " ");
                        }
                        await writer.WriteLineAsync();
                    }
                }
            }
            catch
            {
                throw new EscapeDataException("Error occured while saving.");
            }
        }
    }
}
