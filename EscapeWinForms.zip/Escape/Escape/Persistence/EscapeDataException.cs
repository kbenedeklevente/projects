﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Escape.Persistence
{
    public class EscapeDataException : Exception
    {
        public EscapeDataException(String message) : base(message) { }
    }
}
