﻿namespace Escape.Persistence
{
    public enum Entity
    {
        Empty,
        Player,
        Enemy,
        Bomb
    }
}
