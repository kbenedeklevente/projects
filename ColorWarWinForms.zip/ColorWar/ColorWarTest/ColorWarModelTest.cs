﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ColorWarGame.Persistence;
using ColorWarGame.Model;
using Moq;


namespace ColorWarTest
{
    [TestClass]
    public class ColorWarModelTest
    {
        private ColorWarModel _model = null!;
        private ColorWarBoard _mockedBoard = null!;
        private Mock<IColorWarDataAccess> _mock = null!;

        [TestInitialize]
        public void Initialize()
        {
            _mockedBoard = new ColorWarBoard();
            _mockedBoard.SetValue(0, 0, Colors.Red);
            _mockedBoard.SetValue(0, 1, Colors.Red);
            _mockedBoard.SetValue(2, 0, Colors.Blue);
            _mockedBoard.SetValue(2, 1, Colors.Blue);

            _mock = new Mock<IColorWarDataAccess>();
            _mock.Setup(mock => mock.LoadAsync(It.IsAny<String>()))
                .Returns(() => Task.FromResult(_mockedBoard));

            _model = new ColorWarModel(6, _mock.Object);
            // példányosítjuk a modellt a mock objektummal

            _model.GameOver += new EventHandler<ColorWarEventArgs>(Model_GameOver);
            _model.StateChanged += new EventHandler<ColorWarEventArgs>(Model_StateChanged);
        }

        [TestMethod]
        public void ColorWarModelNewGameSixTest()
        {
            _model.NewGame(6);

            Assert.AreEqual(0, _model.RedArea);
            Assert.AreEqual(0, _model.BlueArea);
            Assert.AreEqual(6, _model.BoardSize);
            Assert.AreEqual(false, _model.Rotated);
            Assert.AreEqual(Colors.Blue, _model.Turn);

            Int32 emptyFields = 0;
            for (Int32 i = 0; i < 6; i++)
                for (Int32 j = 0; j < 6; j++)
                    if (_model.Board[i, j] == Colors.White)
                        emptyFields++;

            Assert.AreEqual(36, emptyFields);
        }

        [TestMethod]
        public void ColorWarModelNewGameEightTest()
        {
            _model.NewGame(8);

            Assert.AreEqual(0, _model.RedArea);
            Assert.AreEqual(0, _model.BlueArea);
            Assert.AreEqual(8, _model.BoardSize);
            Assert.AreEqual(false, _model.Rotated);
            Assert.AreEqual(Colors.Blue, _model.Turn);

            Int32 emptyFields = 0;
            for (Int32 i = 0; i < 8; i++)
                for (Int32 j = 0; j < 8; j++)
                    if (_model.Board[i, j] == Colors.White)
                        emptyFields++;

            Assert.AreEqual(64, emptyFields);
        }

        [TestMethod]
        public void ColorWarModelNewGameTenTest()
        {
            _model.NewGame(10);

            Assert.AreEqual(0, _model.RedArea);
            Assert.AreEqual(0, _model.BlueArea);
            Assert.AreEqual(10, _model.BoardSize);
            Assert.AreEqual(false, _model.Rotated);
            Assert.AreEqual(Colors.Blue, _model.Turn);

            Int32 emptyFields = 0;
            for (Int32 i = 0; i < 10; i++)
                for (Int32 j = 0; j < 10; j++)
                    if (_model.Board[i, j] == Colors.White)
                        emptyFields++;

            Assert.AreEqual(100, emptyFields);
        }

        [TestMethod]
        public void ColorWarModelStepAndRotateTest()
        {

            _model.NewGame(6);

            Assert.AreEqual(0, _model.RedArea);
            Assert.AreEqual(0, _model.BlueArea);
            Assert.AreEqual(Colors.Blue, _model.Turn);

            _model.PlayerTurn(0, 0);

            Assert.AreEqual(Colors.Blue, _model.Board[0, 0]);
            Assert.AreEqual(Colors.Blue, _model.Board[1, 0]);

            Assert.AreEqual(2, _model.BlueArea);
            Assert.AreEqual(0, _model.RedArea);
            Assert.AreEqual(Colors.Red, _model.Turn);

            Random random = new Random();
            Int32 x = 0, y = 0;
            do
            {
                x = random.Next(0, 6);
                y = random.Next(0, 6);
            }
            while (_model.Board.FieldLocked(x, y));

            _model.PlayerTurn(x, y);

            Assert.AreEqual(2, _model.BlueArea);
            Assert.AreEqual(2, _model.RedArea);
            Assert.AreEqual(Colors.Red, _model.Board[x, y]);
            Assert.AreEqual(Colors.Red, _model.Board[x + 1, y]);
            Assert.AreEqual(Colors.Blue, _model.Turn);

            _model.Rotate();
            Assert.AreEqual(true, _model.Rotated);

            do
            {
                x = random.Next(0, 6);
                y = random.Next(0, 6);
            }
            while (_model.Board.FieldLocked(x, y));

            _model.PlayerTurn(x, y);

            Assert.AreEqual(Colors.Blue, _model.Board[x, y]);
            Assert.AreEqual(Colors.Blue, _model.Board[x , y + 1]);
            Assert.AreEqual(Colors.Red, _model.Turn);
        }

        [TestMethod]
        public void ColorWarModelInvalidStep()
        {

            _model.NewGame(6);

            Assert.AreEqual(0, _model.RedArea);
            Assert.AreEqual(0, _model.BlueArea);

            //edges
            for(int i = 0; i < 6; ++i)
            {
                _model.PlayerTurn(5, i);
                Assert.AreEqual(Colors.White, _model.Board[5, i]);
            }
            _model.Rotate();
            for (int i = 0; i < 6; ++i)
            {
                _model.PlayerTurn(i, 5);
                Assert.AreEqual(Colors.White, _model.Board[i, 5]);
            }

            Assert.AreEqual(0, _model.BlueArea);
            Assert.AreEqual(0, _model.RedArea);

            //custom
            _model.NewGame(6);
            _model.Board.SetValue(3, 3, Colors.Blue);
            _model.PlayerTurn(3, 2);
            Assert.AreEqual(Colors.White, _model.Board[3, 2]);

            _model.NewGame(6);
            _model.Rotate();
            _model.Board.SetValue(3, 3, Colors.Blue);
            _model.PlayerTurn(2, 3);
            Assert.AreEqual(Colors.White, _model.Board[2, 3]);
        }

        [TestMethod]
        public async Task ColorWarModelLoadTest()
        {
            _model.NewGame(6);

            await _model.LoadGameAsync(String.Empty);

            for (Int32 i = 0; i < 3; i++)
                for (Int32 j = 0; j < 3; j++)
                {
                    Assert.AreEqual(_mockedBoard.GetValue(i, j), _model.Board.GetValue(i, j));
                    Assert.AreEqual(_mockedBoard.FieldLocked(i, j), _model.Board.FieldLocked(i, j));
                }

            _mock.Verify(dataAccess => dataAccess.LoadAsync(String.Empty), Times.Once());
        }

        [TestMethod]
        public void ColorWarModelIsGameOver()
        {
            _model.NewGame(6);
            Assert.AreEqual(false, _model.IsGameOver);
            for (Int32 i = 0; i < 6; i++)
                for (Int32 j = 0; j < 6; j++)
                    if (_model.Board[i, j] == Colors.White)
                        _model.Board.SetValue(i, j, Colors.Red);
            Assert.AreEqual(true, _model.IsGameOver);

            _model.NewGame(6);
            Assert.AreEqual(false, _model.IsGameOver);
            for (Int32 i = 0; i < 6; i++)
                for (Int32 j = 0; j < 6; j++)
                    if (_model.Board[i, j] == Colors.White)
                        _model.Board.SetValue(i, j, Colors.Blue);
            Assert.AreEqual(true, _model.IsGameOver);

            _model.NewGame(6);
            Assert.AreEqual(false, _model.IsGameOver);
            for (Int32 i = 0; i < 6; i++)
                for (Int32 j = 0; j < 6; j++)
                    if (_model.Board[i, j] == Colors.White)
                        _model.Board.SetValue(i, j, Colors.Temp);
            Assert.AreEqual(true, _model.IsGameOver);
        }

        [TestMethod]
        public async Task ColorWarModelSaveTest()
        {
            _model.NewGame(6);

            await _model.SaveGameAsync(String.Empty);

            _mock.Verify(dataAccess => dataAccess.SaveAsync(String.Empty, _model.Board), Times.Once());
        }

        private void Model_StateChanged(Object? sender, ColorWarEventArgs e)
        {
            Assert.IsTrue(_model.RedArea >= 0);
            Assert.IsTrue(_model.BlueArea >= 0);

            Assert.AreEqual(e.Turn, _model.Turn);
            Assert.AreEqual(e.Rotated, _model.Rotated);
            Assert.AreEqual(e.RedArea, _model.RedArea);
            Assert.AreEqual(e.BlueArea, _model.BlueArea);
            Assert.AreEqual(e.BoardSize, _model.BoardSize);

            Assert.IsFalse(_model.IsGameOver);
        }

        private void Model_GameOver(Object? sender, ColorWarEventArgs e)
        {
            Assert.IsTrue(_model.IsGameOver);
            if (e.ColorWon == Colors.Blue)
                Assert.IsTrue(e.BlueArea > e.RedArea);
            else if (e.ColorWon == Colors.Red)
                Assert.IsTrue(e.BlueArea < e.RedArea);
            else if (e.ColorWon == Colors.Temp)
                Assert.IsTrue(e.BlueArea == e.RedArea);
            else
                Assert.AreEqual(1, 0);
        }
    }
}