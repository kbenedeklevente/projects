﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ColorWarGame.Persistence
{
    public class ColorWarDataException : Exception
    {
        public ColorWarDataException(String message) : base(message) { }
    }
}
