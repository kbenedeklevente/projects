﻿using ColorWarGame.Persistence;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ColorWarGame.Persistence
{
    public class ColorWarFileDataAccess : IColorWarDataAccess
    {
        public async Task<ColorWarBoard> LoadAsync(String path)
        {
            try
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    String line = await reader.ReadLineAsync() ?? String.Empty;
                    String[] numbers = line.Split(' ');
                    Int32 boardSize = Int32.Parse(numbers[0]);
                    Int32 turn = Int32.Parse(numbers[1]);
                    ColorWarBoard board = new ColorWarBoard(boardSize, (Colors)turn);

                    for (Int32 i = 0; i < boardSize; i++)
                    {
                        line = await reader.ReadLineAsync() ?? String.Empty;
                        numbers = line!.Split(' ');

                        for (Int32 j = 0; j < boardSize; j++)
                        {
                            board.SetValue(i, j, (Colors)Int32.Parse(numbers[j]));
                        }
                    }

                    return board;
                }
            }
            catch
            {
                throw new ColorWarDataException("Error occured while loading");
            }
        }

        public async Task SaveAsync(String path, ColorWarBoard board)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(path))
                {
                    writer.Write((Int32)board.BoardSize);
                    await writer.WriteLineAsync(" " + ((Int32)board.Turn));
                    for (Int32 i = 0; i < board.BoardSize; i++)
                    {
                        for (Int32 j = 0; j < board.BoardSize; j++)
                        {
                            await writer.WriteAsync((Int32)board[i, j] + " ");
                        }
                        await writer.WriteLineAsync();
                    }
                }
            }
            catch
            {
                throw new ColorWarDataException("Error occured while saving.");
            }
        }
    }
}

