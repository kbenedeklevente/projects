﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ColorWarGame.Persistence
{

    public class ColorWarBoard
    {

        #region Private fields

        private Colors[,] _gameBoard;
        private Int32 _boardSize;
        private Colors _turn;
        private Boolean _rotated;

        #endregion

        #region Properties

        public Int32 BoardSize { get { return _boardSize; } set { _boardSize = value; } }

        public Colors Turn { get { return _turn; } set { _turn = value; } }

        public Boolean Rotated { get { return _rotated; } set { _rotated = value; } }

        public Int32 RedArea
        {
            get
            {
                return CalculateArea(Colors.Red);
            }
        }

        public Int32 BlueArea
        {
            get
            {
                return CalculateArea(Colors.Blue);
            }
        }

        public Boolean HasRedPlayerWon
        {
            get
            {
                if (RedArea > _boardSize * _boardSize / 2 || (BoardFull && RedArea > BlueArea)) return true;
                else return false;
            }
        }

        public Boolean HasBluePlayerWon
        {
            get
            {
                if (BlueArea > _boardSize * _boardSize / 2 || (BoardFull && BlueArea > BlueArea)) return true;
                else return false;
            }
        }

       public Boolean BoardFull
        {
            get
            {
                for (int i = 0; i < _gameBoard.GetLength(0); i++)
                    for (int j = 0; j < _gameBoard.GetLength(1); j++)
                    {
                        if (_gameBoard[i, j] == Colors.White)
                        {
                            if (i + 1 < _boardSize)
                                if (_gameBoard[i + 1, j] == Colors.White)
                                    return false;
                            if (j + 1 < _boardSize)
                                if (_gameBoard[i, j + 1] == Colors.White)
                                    return false;
                            if (i - 1 >= 0)
                                if (_gameBoard[i - 1, j] == Colors.White)
                                    return false;
                            if (j - 1 >= 0)
                                if (_gameBoard[i, j - 1] == Colors.White)
                                    return false;
                        }
                    }
                return true;
            }
        }

        public Colors this[Int32 x, Int32 y]
        {
            get { return GetValue(x, y); }
        }

        #endregion

        #region Constructors

        public ColorWarBoard() : this(8, Colors.Blue) { }

        public ColorWarBoard(Int32 size, Colors turn)
        {
            if (size < 0)
                throw new ArgumentOutOfRangeException("The board size is less than 0.", "boardSize");
            if (turn != Colors.Blue && turn != Colors.Red)
                throw new ArgumentOutOfRangeException("Starting turns color is not correct", "turn");
            _boardSize = size;
            _turn = turn;
            _rotated = false;
            _gameBoard = new Colors[size, size];
        }

        #endregion

        #region Public methods

        public void GenerateBoard(Int32 newSize)
        {
            _boardSize = newSize;
            if (_gameBoard != null)
            {
                _gameBoard = new Colors[_boardSize, _boardSize];
            }
            for (Int32 i = 0; i < _gameBoard!.GetLength(0); i++)
                for (Int32 j = 0; j < _gameBoard.GetLength(1); j++)
                {
                    _gameBoard[i, j] = Colors.White;
                }
        }

        public void RotateBlock()
        {
            _rotated = !_rotated;
        }

        public Colors GetValue(Int32 x, Int32 y)
        {
            if (x < 0 || x >= _gameBoard.GetLength(0))
                throw new ArgumentOutOfRangeException("x", "The X coordinate is out of range.");
            if (y < 0 || y >= _gameBoard.GetLength(1))
                throw new ArgumentOutOfRangeException("y", "The Y coordinate is out of range.");

            return _gameBoard[x, y];
        }

        public void SetValue(Int32 x, Int32 y, Colors color)
        {
            if (x < 0 || x >= _gameBoard.GetLength(0))
                throw new ArgumentOutOfRangeException("x", "The X coordinate is out of range.");
            if (y < 0 || y >= _gameBoard.GetLength(1))
                throw new ArgumentOutOfRangeException("y", "The Y coordinate is out of range.");

            _gameBoard[x, y] = color;
        }

        public void PlaceBlock(Int32 x, Int32 y)
        {
            if (!_rotated && x < _gameBoard.GetLength(0) - 1 && y < _gameBoard.GetLength(1) && x >= 0 && y >= 0)
            {
                if(CheckPosition(x, y) && CheckPosition(x + 1, y))
                {
                    _gameBoard[x, y] = _turn;
                    _gameBoard[x + 1, y] = _turn;
                }

            }
            if (_rotated && x < _gameBoard.GetLength(0) && y < _gameBoard.GetLength(1) - 1 && x >= 0 && y >= 0)
            {
                if(CheckPosition(x, y) && CheckPosition(x, y + 1))
                {
                    _gameBoard[x, y] = _turn;
                    _gameBoard[x, y + 1] = _turn;
                }
            }

            replaceSurrounded();

            if (_turn == Colors.Red)
                _turn = Colors.Blue;
            else
                _turn = Colors.Red;
            //replaceSurrounded();
        }

        public Boolean FieldLocked(Int32 x,Int32 y)
        {
            if (_rotated && y == _boardSize - 1)
                return true;
            if (!_rotated && x == _boardSize - 1)
                return true;
            if ((_rotated && (_gameBoard[x, y] != Colors.White || _gameBoard[x, y + 1] != Colors.White ))
                || (!_rotated && (_gameBoard[x, y] != Colors.White || _gameBoard[x + 1, y] != Colors.White)))
                    return true;

            return false;
        }

        #endregion

        #region Private methods

        private void FloodFill(int x, int y, Colors prevC, Colors newC)
        {

            if (x < 0 || x >= _gameBoard.GetLength(0) || y < 0 || y >= _gameBoard.GetLength(1))
                return;

            if (_gameBoard[x, y] != prevC)
                return;

            _gameBoard[x, y] = newC;

            FloodFill(x + 1, y, prevC, newC);
            FloodFill(x - 1, y, prevC, newC);
            FloodFill(x, y + 1, prevC, newC);
            FloodFill(x, y - 1, prevC, newC);
            //corners
            FloodFill(x - 1, y - 1, prevC, newC);
            FloodFill(x + 1, y - 1, prevC, newC);
            FloodFill(x + 1, y + 1, prevC, newC);
            FloodFill(x - 1, y + 1, prevC, newC);
        }

        private void replaceSurrounded()
        {
            Colors[,] gameBoardState = new Colors[_boardSize, _boardSize];

            for (int i = 0; i < _gameBoard.GetLength(0); i++)
                for (int j = 0; j < _gameBoard.GetLength(1); j++)
                {
                    gameBoardState[i, j] = _gameBoard[i, j];
                }

            for (int i = 0; i < _gameBoard.GetLength(0); i++)
                for (int j = 0; j < _gameBoard.GetLength(1); j++)
                    if (_turn == Colors.Red)
                    {
                        if (_gameBoard[i, j] != Colors.Red)
                            _gameBoard[i, j] = Colors.Temp;
                    }
                    else
                    {
                        if (_gameBoard[i, j] != Colors.Blue)
                            _gameBoard[i, j] = Colors.Temp;
                    }

            // Left
            for (int i = 0; i < _gameBoard.GetLength(0); i++)
                if (_gameBoard[i, 0] == Colors.Temp)
                    FloodFill(i, 0, Colors.Temp, Colors.White); //gameBoardState[i, 0]

            //Right
            for (int i = 0; i < _gameBoard.GetLength(0); i++)
                if (_gameBoard[i, _boardSize - 1] == Colors.Temp)
                    FloodFill(i, _boardSize - 1, Colors.Temp, Colors.White);
            // Top
            for (int j = 0; j < _gameBoard.GetLength(0); j++)
                if (_gameBoard[0, j] == Colors.Temp)
                    FloodFill(0, j, Colors.Temp, Colors.White);
            // Bottom
            for (int j = 0; j < _gameBoard.GetLength(0); j++)
                if (_gameBoard[_boardSize - 1, j] == Colors.Temp)
                    FloodFill(_boardSize - 1, j, Colors.Temp, Colors.White);

            for (int i = 0; i < _gameBoard.GetLength(0); i++)
                for (int j = 0; j < _gameBoard.GetLength(1); j++)
                    if (_gameBoard[i, j] == Colors.Temp)
                    {
                        if (_turn == Colors.Red)
                            _gameBoard[i, j] = Colors.LightRed;
                        else
                            _gameBoard[i, j] = Colors.LightBlue;
                    }

            for (int i = 0; i < _gameBoard.GetLength(0); i++)
                for (int j = 0; j < _gameBoard.GetLength(1); j++)
                {
                    if (_turn == Colors.Red && _gameBoard[i, j] != Colors.LightRed)
                        _gameBoard[i, j] = gameBoardState[i, j];
                    if (_turn == Colors.Blue && _gameBoard[i, j] != Colors.LightBlue)
                        _gameBoard[i, j] = gameBoardState[i, j];
                }
        }

        private Int32 CalculateArea(Colors color)
        {
            int count=0;
            for (Int32 i = 0; i < _gameBoard.GetLength(0); ++i)
            {
                for (Int32 j = 0; j < _gameBoard.GetLength(1); ++j)
                {
                    if(color == Colors.Red)
                    {
                        if (_gameBoard[i, j] == Colors.Red || _gameBoard[i, j] == Colors.LightRed) count++;
                    }
                    else
                    {
                        if (_gameBoard[i, j] == Colors.Blue || _gameBoard[i, j] == Colors.LightBlue) count++;
                    }
                }
            }
            return count;
        }

        private Boolean CheckPosition(Int32 x, Int32 y)
        {
            if (_gameBoard[x, y] == Colors.White)
                return true;
            return false;
        }

        #endregion
    }
}
