﻿using ColorWarGame.Persistence;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ColorWarGame.Model
{

    public class ColorWarModel
    {
        #region Private fields

        private ColorWarBoard _board;
        private IColorWarDataAccess _dataAccess;

        #endregion

        #region Public properties

        public Int32 BoardSize { get { return _board.BoardSize; } set { _board.BoardSize = value; } }

        public Colors Turn { get { return _board.Turn; } set { _board.Turn = value; } }

        public Boolean Rotated { get { return _board.Rotated; } set { _board.Rotated = value; } }

        public Int32 RedArea { get { return _board.RedArea; } }

        public Int32 BlueArea { get { return _board.BlueArea; } }

        public ColorWarBoard Board { get { return _board; } }

        public Boolean IsGameOver { get { return ( _board.HasBluePlayerWon || _board.HasRedPlayerWon || _board.BoardFull); } }

        public Colors this[Int32 x, Int32 y]
        {
            get
            {
                if (x < 0 || x >= _board.BoardSize)
                    throw new ArgumentException("Bad column index.", nameof(x));
                if (y < 0 || y >= _board.BoardSize)
                    throw new ArgumentException("Bad row index.", nameof(y));

                return _board[x, y];
            }
        }

        #endregion

        #region Events

        public event EventHandler<ColorWarEventArgs>? GameOver;

        public event EventHandler<ColorWarEventArgs>? StateChanged;

        #endregion

        #region Constructors

        public ColorWarModel(Int32 boardSize, IColorWarDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
            _board = new ColorWarBoard(boardSize, Colors.Blue);
            NewGame(boardSize);
        }

        #endregion

        #region Public methods

        public void PlayerTurn(Int32 x, Int32 y)
        {
            _board.PlaceBlock(x, y);
            OnStateChanged();
            if (_board.HasRedPlayerWon || (_board.BoardFull && _board.RedArea > _board.BlueArea))
            {
                OnGameOver(Colors.Red);
            }
            if (_board.HasBluePlayerWon || (_board.BoardFull && _board.RedArea < _board.BlueArea))
            {
                OnGameOver(Colors.Blue);
            }
            if(_board.BoardFull && _board.RedArea == _board.BlueArea)
            {
                OnGameOver(Colors.Temp);
            }

        }

        public Boolean CheckField(Int32 x, Int32 y)
        {
            return !_board.FieldLocked(x, y);

        }

        public void Rotate()
        {
            _board.RotateBlock();
        }

        public void NewGame(Int32 size)
        {
            _board.GenerateBoard(size);
        }

        public async Task LoadGameAsync(String path)
        {
            if (_dataAccess == null)
                throw new InvalidOperationException("No data access is provided.");

            _board = await _dataAccess.LoadAsync(path);

            
            if (_board.HasRedPlayerWon)
            {
                OnGameOver(Colors.Red);
            }
            if (_board.HasBluePlayerWon)
            {
                OnGameOver(Colors.Blue);
            }
            if (_board.BoardFull)
            {
                OnGameOver(Colors.Temp);
            }

        }

        public async Task SaveGameAsync(String path)
        {
            if (_dataAccess == null)
                throw new InvalidOperationException("No data access is provided.");

            await _dataAccess.SaveAsync(path, _board);
        }
        #endregion

        #region Event triggers

        private void OnGameOver(Colors color)
        {
            if (GameOver != null)
                GameOver(this, new ColorWarEventArgs(BoardSize, color, RedArea, BlueArea, Rotated, Turn));

        }

        private void OnStateChanged()
        {
            if (StateChanged != null)
                StateChanged(this, new ColorWarEventArgs(BoardSize, Colors.White, RedArea, BlueArea, Rotated, Turn));
        }

        #endregion
    }
}
