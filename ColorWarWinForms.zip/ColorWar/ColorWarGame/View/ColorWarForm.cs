﻿using System;
using System.Collections.Specialized;
using System.Drawing;
using System.Numerics;
using System.Security.Policy;
using System.Windows.Forms;
using ColorWarGame.Model;
using ColorWarGame.Persistence;

namespace ColorWarGame.View
{
    public partial class ColorWarForm : Form
    {

        #region Size constants

        private const Int32 Six = 6;
        private const Int32 Eight = 8;
        private const Int32 Ten = 10;

        #endregion

        #region Private fields

        private IColorWarDataAccess _dataAccess = null!;
        private ColorWarModel _model = null!;
        private Button[,] _buttonGrid = null!;

        #endregion

        #region Constructors

        public ColorWarForm()
        {
            InitializeComponent();

            _dataAccess = new ColorWarFileDataAccess();

            _model = new ColorWarModel(Six, _dataAccess);
            _model.StateChanged += new EventHandler<ColorWarEventArgs>(Model_StateChanged);
            _model.GameOver += new EventHandler<ColorWarEventArgs>(Model_GameWon);

            this.ClientSize = new Size(80 * _model.BoardSize, 80 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);
            _tableLayoutPanel.RowCount = Six;
            _tableLayoutPanel.ColumnCount = Six;
        }

        #endregion

        #region Private methods

        private void GenerateTable()
        {
            Int32 size = _model.BoardSize;
            if (_buttonGrid != null)
            {
                foreach (Button button in _buttonGrid)
                    _tableLayoutPanel.Controls.Remove(button);
            }
            _buttonGrid = new GridButton[size, size];

            this.ClientSize = new Size(80 * _model.BoardSize, 80 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);
            _tableLayoutPanel.RowCount = size;
            _tableLayoutPanel.ColumnCount = size;

            for (Int32 i = 0; i < size; i++)
            {
                for (Int32 j = 0; j < size; j++)
                {
                    _buttonGrid[i, j] = new GridButton(i, j);
                    _buttonGrid[i, j].BackColor = Color.White;
                    _buttonGrid[i, j].Dock = DockStyle.Fill;
                    _buttonGrid[i, j].MouseClick += new MouseEventHandler(ButtonGrid_MouseClick);
                    _buttonGrid[i, j].MouseEnter += new EventHandler(ButtonGrid_MouseEnter);
                    _buttonGrid[i, j].MouseLeave += new EventHandler(ButtonGrid_MouseLeave);
                    _tableLayoutPanel.Controls.Add(_buttonGrid[i, j], j, i);
                }
            }
            _buttonGrid[size - 1, size - 1].Enabled = false;

            _tableLayoutPanel.RowStyles.Clear();
            _tableLayoutPanel.ColumnStyles.Clear();

            this.ClientSize = new Size(80 * _model.BoardSize, 80 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);

            for (Int32 i = 0; i < size; i++)
            {
                _tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 1 / Convert.ToSingle(size - 1)));
            }
            for (Int32 j = 0; j < size; j++)
            {
                _tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 1 / Convert.ToSingle(size - 1)));
            }

            DisableButtons();
        }

        private void UpdateTable()
        {
            Int32 size = _model.BoardSize;
            for (Int32 i = 0; i < size; i++)
                for (Int32 j = 0; j < size; j++)
                {
                    _buttonGrid[i, j].BackColor = GetColor(_model.Board[i, j]);
                }
            DisableButtons();
        }

        private Color GetColor(Colors color)
        {
            switch (color)
            {
                case Colors.White:
                    return Color.White;
                case Colors.Red:
                    return Color.Red;
                case Colors.Blue:
                    return Color.Blue;
                case Colors.LightBlue:
                    return Color.LightBlue;
                case Colors.LightRed:
                    return Color.PaleVioletRed;
                default:
                    return Color.Black;
            }
        }

        private void DisableButtons()
        {
            Int32 size = _model.BoardSize;
            if (_model.Rotated)
            {
                for (int j = 0; j < size - 1; ++j)
                {
                    _buttonGrid[j, size - 1].Enabled = false;
                }
                for (int i = 0; i < size - 1; ++i)
                {
                    _buttonGrid[size - 1, i].Enabled = true;
                }
            }
            else
            {
                for (int i = 0; i < size - 1; ++i)
                {
                    _buttonGrid[size - 1, i].Enabled = false;
                }
                for (int j = 0; j < size - 1; ++j)
                {
                    _buttonGrid[j, size - 1].Enabled = true;
                }
            }
            if( _model.Rotated)
                for (int j = 0; j < size - 1; ++j)
                    for (int i = 0; i < size; ++i)
                        _buttonGrid[i, j].Enabled = _model.CheckField(i, j);
            else
                for (int j = 0; j < size; ++j)
                    for (int i = 0; i < size - 1; ++i)
                        _buttonGrid[i, j].Enabled = _model.CheckField(i, j);
            ColorDisabledButtons();
        }

        private void ColorDisabledButtons()
        {
            for (int j = 0; j < _model.BoardSize; ++j)
                for (int i = 0; i < _model.BoardSize; ++i)
                {
                    if (!_buttonGrid[i, j].Enabled && _buttonGrid[i, j].BackColor == Color.White) _buttonGrid[i, j].BackColor = Color.LightGray;
                    if (_buttonGrid[i, j].Enabled && _buttonGrid[i, j].BackColor == Color.LightGray) _buttonGrid[i, j].BackColor = Color.White;
                }
        }

        #endregion

        #region Model events

        private void Model_GameWon(object? sender, ColorWarEventArgs e)
        {
            switch (e.ColorWon)
            {
                case Colors.Red:
                    MessageBox.Show("A piros játékos győzött!", "Játék vége!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    break;
                case Colors.Blue:
                    MessageBox.Show("A Kék játékos győzött!", "Játék vége!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    break;
                case Colors.Temp:
                    MessageBox.Show("A játék döntetlen lett!", "Játék vége!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    break;
            }
            _model.NewGame(Six);

            GenerateTable();
            this.ClientSize = new Size(80 * _model.BoardSize, 80 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);
            _statusBlueArea.Text = "0";
            _statusRedArea.Text = "0";
        }

        private void Model_StateChanged(object? sender, ColorWarEventArgs e)
        {
            _statusBlueArea.Text = e.BlueArea.ToString();
            _statusRedArea.Text = e.RedArea.ToString();
            UpdateTable();
        }

        #endregion

        #region Form event handlers

        private void ColorWarForm_Load(object? sender, EventArgs e)
        {
            //_model.NewGame(_model.BoardSize);
            this.ClientSize = new Size(80 * _model.BoardSize, 80 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);
            GenerateTable();
            UpdateTable();
        }

        #endregion

        #region Grid event handlers

        private void ButtonGrid_MouseClick(object? sender, EventArgs e)
        {
            if (sender is GridButton button)
            {
                Int32 x = button.GridX;
                Int32 y = button.GridY;

                _model.PlayerTurn(x, y);
            }
        }


        private void ButtonGrid_MouseEnter(object? sender, EventArgs e)
        {
            if (sender is GridButton button)
            {
                Int32 x = button.GridX;
                Int32 y = button.GridY;
                if (!_model.Rotated)
                {
                    _buttonGrid[x, y].BackColor = GetColor(_model.Turn);
                    _buttonGrid[x + 1, y].BackColor = GetColor(_model.Turn);
                }
                else
                {
                    _buttonGrid[x, y].BackColor = GetColor(_model.Turn);
                    _buttonGrid[x, y + 1].BackColor = GetColor(_model.Turn);
                }
            }
            ColorDisabledButtons();
        }

        private void ButtonGrid_MouseLeave(object? sender, EventArgs e)
        {
            if (sender is GridButton button)
            {
                Int32 x = button.GridX;
                Int32 y = button.GridY;

                if (!_model.Rotated)
                {
                    _buttonGrid[x, y].BackColor = GetColor(_model.Board[x, y]);
                    _buttonGrid[x + 1, y].BackColor = GetColor(_model.Board[x + 1, y]);
                }
                else
                {
                    _buttonGrid[x, y].BackColor = GetColor(_model.Board[x, y]);
                    _buttonGrid[x, y + 1].BackColor = GetColor(_model.Board[x, y + 1]);
                }
            }
            ColorDisabledButtons();
        }

        #endregion

        #region Menu event handlers

        private void Rotate_Click(object? sender, EventArgs e)
        {
            _model.Rotate();
            DisableButtons();
        }

        private void MenuSix_Click(object? sender, EventArgs e)
        {
            _model.BoardSize = Six;
            _model.NewGame(Six);
            this.ClientSize = new Size(80 * _model.BoardSize, 80 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);
            GenerateTable();
            _statusBlueArea.Text = "0";
            _statusRedArea.Text = "0";
        }

        private void MenuEight_Click(object? sender, EventArgs e)
        {
            _model.BoardSize = Eight;
            _model.NewGame(Eight);
            this.ClientSize = new Size(80 * _model.BoardSize, 80 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);
            GenerateTable();
            _statusBlueArea.Text = "0";
            _statusRedArea.Text = "0";
        }

        private void MenuTen_Click(object? sender, EventArgs e)
        {
            _model.BoardSize = Ten;
            _model.NewGame(Ten);
            this.ClientSize = new Size(80 * _model.BoardSize, 80 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);
            GenerateTable();
            _statusBlueArea.Text = "0";
            _statusRedArea.Text = "0";
        }

        private async void MenuLoad_Click(object? sender, EventArgs e)
        {
            if (_openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    await _model.LoadGameAsync(_openFileDialog.FileName);
                }
                catch (ColorWarDataException)
                {
                    MessageBox.Show("An error occured during loading.", "Escape", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
                GenerateTable();
                UpdateTable();
                this.ClientSize = new Size(80 * _model.BoardSize, 80 * _model.BoardSize + _menuStrip.Height + _statusStrip.Height);
            }
        }

        private async void MenuSave_Click(object? sender, EventArgs e)
        {
            if (_saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    await _model.SaveGameAsync(_saveFileDialog.FileName);
                }
                catch (ColorWarDataException)
                {
                    MessageBox.Show("An error occured during saving.", "Escape", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        #endregion
    }
}