﻿namespace ColorWarGame.View
{
    partial class ColorWarForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._menuStrip = new System.Windows.Forms.MenuStrip();
            this._menuFile = new System.Windows.Forms.ToolStripMenuItem();
            this._menuSave = new System.Windows.Forms.ToolStripMenuItem();
            this._menuLoad = new System.Windows.Forms.ToolStripMenuItem();
            this._menuNewGame = new System.Windows.Forms.ToolStripMenuItem();
            this._menuSixSize = new System.Windows.Forms.ToolStripMenuItem();
            this._menuEightSize = new System.Windows.Forms.ToolStripMenuItem();
            this._menuTenSize = new System.Windows.Forms.ToolStripMenuItem();
            this._menuRotate = new System.Windows.Forms.ToolStripMenuItem();
            this._statusStrip = new System.Windows.Forms.StatusStrip();
            this._statusBlueText = new System.Windows.Forms.ToolStripStatusLabel();
            this._statusBlueArea = new System.Windows.Forms.ToolStripStatusLabel();
            this._statusRedText = new System.Windows.Forms.ToolStripStatusLabel();
            this._statusRedArea = new System.Windows.Forms.ToolStripStatusLabel();
            this._tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this._openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this._saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this._menuStrip.SuspendLayout();
            this._statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // _menuStrip
            // 
            this._menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._menuFile,
            this._menuNewGame,
            this._menuRotate});
            this._menuStrip.Location = new System.Drawing.Point(0, 0);
            this._menuStrip.Name = "_menuStrip";
            this._menuStrip.Size = new System.Drawing.Size(420, 24);
            this._menuStrip.TabIndex = 0;
            this._menuStrip.Text = "menuStrip1";
            // 
            // _menuFile
            // 
            this._menuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._menuSave,
            this._menuLoad});
            this._menuFile.Name = "_menuFile";
            this._menuFile.Size = new System.Drawing.Size(37, 20);
            this._menuFile.Text = "File";
            // 
            // _menuSave
            // 
            this._menuSave.Name = "_menuSave";
            this._menuSave.Size = new System.Drawing.Size(100, 22);
            this._menuSave.Text = "Save";
            this._menuSave.Click += new System.EventHandler(this.MenuSave_Click);
            // 
            // _menuLoad
            // 
            this._menuLoad.Name = "_menuLoad";
            this._menuLoad.Size = new System.Drawing.Size(100, 22);
            this._menuLoad.Text = "Load";
            this._menuLoad.Click += new System.EventHandler(this.MenuLoad_Click);
            // 
            // _menuNewGame
            // 
            this._menuNewGame.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._menuSixSize,
            this._menuEightSize,
            this._menuTenSize});
            this._menuNewGame.Name = "_menuNewGame";
            this._menuNewGame.Size = new System.Drawing.Size(77, 20);
            this._menuNewGame.Text = "New Game";
            // 
            // _menuSixSize
            // 
            this._menuSixSize.Name = "_menuSixSize";
            this._menuSixSize.Size = new System.Drawing.Size(110, 22);
            this._menuSixSize.Text = "6 x 6";
            this._menuSixSize.Click += new System.EventHandler(this.MenuSix_Click);
            // 
            // _menuEightSize
            // 
            this._menuEightSize.Name = "_menuEightSize";
            this._menuEightSize.Size = new System.Drawing.Size(110, 22);
            this._menuEightSize.Text = "8 x 8";
            this._menuEightSize.Click += new System.EventHandler(this.MenuEight_Click);
            // 
            // _menuTenSize
            // 
            this._menuTenSize.Name = "_menuTenSize";
            this._menuTenSize.Size = new System.Drawing.Size(110, 22);
            this._menuTenSize.Text = "10 x 10";
            this._menuTenSize.Click += new System.EventHandler(this.MenuTen_Click);
            // 
            // _menuRotate
            // 
            this._menuRotate.Name = "_menuRotate";
            this._menuRotate.Size = new System.Drawing.Size(53, 20);
            this._menuRotate.Text = "Rotate";
            this._menuRotate.Click += new System.EventHandler(this.Rotate_Click);
            // 
            // _statusStrip
            // 
            this._statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._statusBlueText,
            this._statusBlueArea,
            this._statusRedText,
            this._statusRedArea});
            this._statusStrip.Location = new System.Drawing.Point(0, 385);
            this._statusStrip.Name = "_statusStrip";
            this._statusStrip.Size = new System.Drawing.Size(420, 22);
            this._statusStrip.TabIndex = 1;
            this._statusStrip.Text = "statusStrip1";
            // 
            // _statusBlueText
            // 
            this._statusBlueText.Name = "_statusBlueText";
            this._statusBlueText.Size = new System.Drawing.Size(60, 17);
            this._statusBlueText.Text = "Blue Area:";
            // 
            // _statusBlueArea
            // 
            this._statusBlueArea.Name = "_statusBlueArea";
            this._statusBlueArea.Size = new System.Drawing.Size(13, 17);
            this._statusBlueArea.Text = "0";
            // 
            // _statusRedText
            // 
            this._statusRedText.Name = "_statusRedText";
            this._statusRedText.Size = new System.Drawing.Size(57, 17);
            this._statusRedText.Text = "Red Area:";
            // 
            // _statusRedArea
            // 
            this._statusRedArea.Name = "_statusRedArea";
            this._statusRedArea.Size = new System.Drawing.Size(13, 17);
            this._statusRedArea.Text = "0";
            // 
            // _tableLayoutPanel
            // 
            this._tableLayoutPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this._tableLayoutPanel.ColumnCount = 3;
            this._tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.48201F));
            this._tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.51799F));
            this._tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 141F));
            this._tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._tableLayoutPanel.Location = new System.Drawing.Point(0, 24);
            this._tableLayoutPanel.Name = "_tableLayoutPanel";
            this._tableLayoutPanel.RowCount = 3;
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this._tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 127F));
            this._tableLayoutPanel.Size = new System.Drawing.Size(420, 361);
            this._tableLayoutPanel.TabIndex = 2;
            // 
            // _openFileDialog
            // 
            this._openFileDialog.Filter = "ColorWar board|*.stl";
            this._openFileDialog.Title = "Color War - Load Game";
            // 
            // _saveFileDialog
            // 
            this._saveFileDialog.Filter = "ColorWar board|*.stl";
            this._saveFileDialog.Title = "Color War - Save Game";
            // 
            // ColorWarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 407);
            this.Controls.Add(this._tableLayoutPanel);
            this.Controls.Add(this._statusStrip);
            this.Controls.Add(this._menuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this._menuStrip;
            this.MaximizeBox = false;
            this.Name = "ColorWarForm";
            this.Text = "Color War";
            this.Load += new System.EventHandler(this.ColorWarForm_Load);
            this._menuStrip.ResumeLayout(false);
            this._menuStrip.PerformLayout();
            this._statusStrip.ResumeLayout(false);
            this._statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MenuStrip _menuStrip;
        private ToolStripMenuItem _menuFile;
        private ToolStripMenuItem _menuSave;
        private ToolStripMenuItem _menuLoad;
        private ToolStripMenuItem _menuNewGame;
        private ToolStripMenuItem _menuSixSize;
        private ToolStripMenuItem _menuEightSize;
        private ToolStripMenuItem _menuTenSize;
        private StatusStrip _statusStrip;
        private TableLayoutPanel _tableLayoutPanel;
        private ToolStripStatusLabel _statusBlueText;
        private ToolStripStatusLabel _statusBlueArea;
        private ToolStripStatusLabel _statusRedText;
        private ToolStripStatusLabel _statusRedArea;
        private OpenFileDialog _openFileDialog;
        private SaveFileDialog _saveFileDialog;
        private ToolStripMenuItem _menuRotate;
    }
}