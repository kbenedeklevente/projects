﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using Escape.Model;
using Escape.Persistence;
using Escape.ViewModel;
using Escape.View;
using Microsoft.Win32;

namespace Escape
{
    public partial class App : Application
    {
        #region Fields

        private EscapeGameModel _model;
        private EscapeViewModel _viewModel;
        private MainWindow _view;
        private DispatcherTimer _timer;

        #endregion

        #region Constructors

        public App()
        {
            Startup += new StartupEventHandler(App_Startup);
        }

        #endregion

        #region Application event handlers

        private void App_Startup(object sender, StartupEventArgs e)
        {
            _model = new EscapeGameModel(15, new EscapeFileDataAccess());
            _viewModel = new EscapeViewModel(_model);
            _model.GameOver += new EventHandler<EscapeEventArgs>(Model_GameOver);
            _model.NewGame();

            _viewModel.NewGameSmall += new EventHandler(ViewModel_NewGameSmall);
            _viewModel.NewGameMedium += new EventHandler(ViewModel_NewGameMedium);
            _viewModel.NewGameLarge += new EventHandler(ViewModel_NewGameLarge);
            
            _viewModel.PauseGame += new EventHandler(ViewModel_PauseGame);
            _viewModel.ExitGame += new EventHandler(ViewModel_ExitGame);
            _viewModel.LoadGame += new EventHandler(ViewModel_LoadGame);
            _viewModel.SaveGame += new EventHandler(ViewModel_SaveGame);

            _view = new MainWindow();
            _view.DataContext = _viewModel;
            _view.Closing += new System.ComponentModel.CancelEventHandler(View_Closing);
            _view.KeyDown += new KeyEventHandler(Window_KeyDown);
            _view.Show();


            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += new EventHandler(Timer_Tick);
            _timer.Start();
        }

        #endregion

        #region View event handlers

        private void View_Closing(object sender, CancelEventArgs e)
        {
            Boolean restartTimer = _timer.IsEnabled;

            _timer.Stop();
            _view.KeyDown -= Window_KeyDown;

            if (MessageBox.Show("Quit?", "Escape", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No)
            {
                e.Cancel = true;

                if (restartTimer)
                    _timer.Start();
            }
            _view.KeyDown += Window_KeyDown;
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.W:
                    _model.PlayerTurn(0, -1);
                    break;
                case Key.S:
                    _model.PlayerTurn(0, 1);
                    break;
                case Key.D:
                    _model.PlayerTurn(1, 0);
                    break;
                case Key.A:
                    _model.PlayerTurn(-1, 0);
                    break;
            }
        }

        #endregion

        #region ViewModel event handlers

        private void ViewModel_NewGameSmall(object sender, EventArgs e)
        {
            Boolean startTimer = _timer.IsEnabled;
            _timer.Stop();
            _viewModel.BoardSize = 11;
            _model.BoardSize = 11;
            _model.NewGame();
            if (startTimer)
                _timer.Start();
        }

        private void ViewModel_NewGameMedium(object sender, EventArgs e)
        {
            Boolean startTimer = _timer.IsEnabled;
            _viewModel.BoardSize = 15;
            _model.NewGame();
            if (startTimer)
                _timer.Start();
        }

        private void ViewModel_NewGameLarge(object sender, EventArgs e)
        {
            Boolean startTimer = _timer.IsEnabled;
            _viewModel.BoardSize = 21;
            _model.NewGame();
            if (startTimer)
                _timer.Start();
        }

        private void ViewModel_PauseGame(object sender, EventArgs e)
        {
            if (_timer.IsEnabled)
            {
                _view._pause.Header = "Unpause";
                _timer.Stop();
                _view.KeyDown -= Window_KeyDown;
                _view._saveGame.IsEnabled = true;
                _view._loadGame.IsEnabled = true;
            }
            else
            {
                _view._pause.Header = "Pause";
                _timer.Start();
                _view.KeyDown += Window_KeyDown;
                _view._saveGame.IsEnabled = false;
                _view._loadGame.IsEnabled = false;
            }
        }

        private async void ViewModel_LoadGame(object sender, System.EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Title = "Load game";
                openFileDialog.Filter = "Escape board|*.stl";
                if (openFileDialog.ShowDialog() == true)
                {
                    await _model.LoadGameAsync(openFileDialog.FileName);
                }
            }
            catch (EscapeDataException)
            {
                MessageBox.Show("An error occured while loading the file!", "Escape", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void ViewModel_SaveGame(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Title = "Load game";
                saveFileDialog.Filter = "Escape board|*.stl";
                if (saveFileDialog.ShowDialog() == true)
                {
                    try
                    { 
                        await _model.SaveGameAsync(saveFileDialog.FileName);
                    }
                    catch (EscapeDataException)
                    {
                        MessageBox.Show("An error occured while saving the game", "Escape", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch
            {
                MessageBox.Show("Saving file was unsuccesfull", "Escape", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ViewModel_ExitGame(object sender, System.EventArgs e)
        {
            _view.Close();
        }

        #endregion

        #region Model event handlers

        private void Model_GameOver(object sender, EscapeEventArgs e)
        {
            _view.KeyDown -= Window_KeyDown;
            _view._saveGame.IsEnabled = false;
            _timer.Stop();

            switch (e.IsWon)
            {
                case true:
                    MessageBox.Show("You won! :D" + Environment.NewLine + $"You escaped the enemies in {e.GameTime} seconds.", "Escape", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                    break;
                case false:
                    MessageBox.Show("You lost! ;(" + Environment.NewLine + $"The enemies caught you in {e.GameTime} seconds.", "Escape", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                    break;
            }
            _view.KeyDown += Window_KeyDown;
            _model.NewGame();
            _timer.Start();
        }

        #endregion

        #region Timer event handlers

        private void Timer_Tick(object sender, EventArgs e)
        {
            _model.EnemyTurn();
            _model.AdvanceTime();
        }

        #endregion
    }
}
