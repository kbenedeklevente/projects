﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Escape.Persistence
{
    public interface IEscapeDataAccess
    {
        Task<EscapeBoard> LoadAsync(String path);

        Task SaveAsync(String path, EscapeBoard board);
    }
}
