﻿using System;
using System.Collections.Generic;


namespace Escape.Persistence
{
    public class EscapeBoard
    {

        #region Private fields

        private Entity[,] _gameBoard;
        private Int32 _boardSize;
        private Int32 _gameTime;

        #endregion

        #region Properties

        public Int32 BoardSize { get { return _boardSize; } set { _boardSize = value; } }

        public Int32 GameTime { get { return _gameTime; } set { _gameTime = value; } }

        public Boolean IsPlayerDead
        {
            get
            {
                if(GetPlayerPos() == (-1,-1))
                    return true;
                return false;
            }
        }

        public Boolean AreEnemiesDead
        {
            get
            {
                if(GetEnemyPos().Count == 0)
                    return true;
                return false;
            }
        }


        public Entity this[Int32 x, Int32 y]
        {
            get { return GetValue(x, y); }
        }

        #endregion

        #region Constructors

        public EscapeBoard() : this(15, 0) { }

        public EscapeBoard(Int32 size, Int32 time)
        {
            if (size < 0)
                throw new ArgumentOutOfRangeException("The board size is less than 0.", "boardSize");
            _boardSize = size;
            _gameTime = time;
            _gameBoard = new Entity[size, size];
        }
        #endregion

        #region Public methods

        public void GenerateBoard()
        {
            if (_gameBoard != null)
            {
                _gameBoard = new Entity[_boardSize, _boardSize];
                _gameTime = 0;
            }
            for (Int32 i = 0; i < _gameBoard.GetLength(0); i++)
                for (Int32 j = 0; j < _gameBoard.GetLength(1); j++)
                {
                    _gameBoard[i, j] = Entity.Empty;
                }
            _gameBoard[_boardSize / 2, _gameBoard.GetLength(1) - 1] = Entity.Player;
            _gameBoard[_boardSize / 4 + 1, 0] = Entity.Enemy;
            _gameBoard[3 * _boardSize / 4 - 1, 0] = Entity.Enemy;
            _gameBoard[0, _boardSize / 3] = Entity.Enemy;
            _gameBoard[_boardSize - 1, _boardSize / 3] = Entity.Enemy;
            for (Int32 i = 1; i < 4; ++i)
            {
                _gameBoard[i * _boardSize / 4, i * _boardSize / 4] = Entity.Bomb;
                _gameBoard[(i) * _boardSize / 4, (4 - i) * _boardSize / 4] = Entity.Bomb;
            }
            _gameBoard[2 * _boardSize / 4, 2 * _boardSize / 4] = Entity.Enemy;
        }

        public Entity GetValue(Int32 x, Int32 y)
        {
            if (x < 0 || x >= _gameBoard.GetLength(0))
                throw new ArgumentOutOfRangeException("x", "The X coordinate is out of range.");
            if (y < 0 || y >= _gameBoard.GetLength(1))
                throw new ArgumentOutOfRangeException("y", "The Y coordinate is out of range.");

            return _gameBoard[x, y];
        }

        public void SetValue(Int32 x, Int32 y, Entity entity)
        {
            if (x < 0 || x >= _gameBoard.GetLength(0))
                throw new ArgumentOutOfRangeException("x", "The X coordinate is out of range.");
            if (y < 0 || y >= _gameBoard.GetLength(1))
                throw new ArgumentOutOfRangeException("y", "The Y coordinate is out of range.");

            _gameBoard[x, y] = entity;
        }

        public void StepEnemy()
        {
            (Int32 X, Int32 Y) player = GetPlayerPos();
            foreach ((Int32 X, Int32 Y) enemy in GetEnemyPos())
            {
                _gameBoard[enemy.X, enemy.Y] = Entity.Empty;
                if (Math.Abs(player.X - enemy.X) > Math.Abs(player.Y - enemy.Y) && player.X > enemy.X)
                {
                    if (_gameBoard[enemy.X + 1, enemy.Y] == Entity.Empty || _gameBoard[enemy.X + 1, enemy.Y] == Entity.Player)
                    {
                        CheckStep(enemy.X + 1, enemy.Y);
                        _gameBoard[enemy.X + 1, enemy.Y] = Entity.Enemy;
                    }
                    else if (_gameBoard[enemy.X + 1, enemy.Y] == Entity.Enemy)
                    {
                        _gameBoard[enemy.X, enemy.Y] = Entity.Enemy;
                    }
                    else { }
                }
                else if (Math.Abs(player.X - enemy.X) > Math.Abs(player.Y - enemy.Y) && player.X < enemy.X)
                {
                    if (_gameBoard[enemy.X - 1, enemy.Y] == Entity.Empty || _gameBoard[enemy.X - 1, enemy.Y] == Entity.Player)
                    {
                        CheckStep(enemy.X - 1, enemy.Y);
                        _gameBoard[enemy.X - 1, enemy.Y] = Entity.Enemy;
                    }
                    else if (_gameBoard[enemy.X - 1, enemy.Y] == Entity.Enemy)
                    {
                        _gameBoard[enemy.X, enemy.Y] = Entity.Enemy;
                    }
                    else { }
                }
                else if (Math.Abs(player.X - enemy.X) <= Math.Abs(player.Y - enemy.Y) && player.Y > enemy.Y)
                {
                    if (_gameBoard[enemy.X, enemy.Y + 1] == Entity.Empty || _gameBoard[enemy.X, enemy.Y + 1] == Entity.Player)
                    {
                        CheckStep(enemy.X, enemy.Y + 1);
                        _gameBoard[enemy.X, enemy.Y + 1] = Entity.Enemy;
                    }
                    else if (_gameBoard[enemy.X, enemy.Y + 1] == Entity.Enemy)
                    {
                        _gameBoard[enemy.X, enemy.Y] = Entity.Enemy;
                    }
                    else { }
                }
                else if (Math.Abs(player.X - enemy.X) <= Math.Abs(player.Y - enemy.Y) && player.Y < enemy.Y)
                {
                    if (_gameBoard[enemy.X, enemy.Y - 1] == Entity.Empty || _gameBoard[enemy.X, enemy.Y - 1] == Entity.Player)
                    {
                        CheckStep(enemy.X, enemy.Y - 1);
                        _gameBoard[enemy.X, enemy.Y - 1] = Entity.Enemy;
                    }
                    else if (_gameBoard[enemy.X, enemy.Y - 1] == Entity.Enemy)
                    {
                        _gameBoard[enemy.X, enemy.Y] = Entity.Enemy;
                    }
                    else { }
                }
            }
        }

        public void StepPlayer(Int32 x, Int32 y)
        {
            (Int32 X, Int32 Y) player = GetPlayerPos();
            if (!(player.X + x < 0 || player.X + x >= _gameBoard.GetLength(0) || player.Y + y < 0 || player.Y + y >= _gameBoard.GetLength(0)))
            {
                _gameBoard[player.X, player.Y] = Entity.Empty;
                if (_gameBoard[player.X + x, player.Y + y] == Entity.Bomb)
                {
                }
                else if (_gameBoard[player.X + x, player.Y + y] == Entity.Enemy)
                {
                }
                else
                {
                    CheckStep(player.X + x, player.Y + y);
                    _gameBoard[player.X + x, player.Y + y] = Entity.Player;
                }
            }
        }

        #endregion

        #region Private methods

        private (Int32 X, Int32 Y) GetPlayerPos()
        {
            (Int32 X, Int32 Y) p = (-1, -1);
            for (Int32 i = 0; i < _gameBoard.GetLength(0); ++i)
            {
                for (Int32 j = 0; j < _gameBoard.GetLength(1); ++j)
                {
                    if (_gameBoard[i, j] == Entity.Player)
                    {
                        p = (i, j);
                        return p;
                    }
                }
            }
            return p;
        }

        private List<(Int32 X, Int32 Y)> GetEnemyPos()
        {
            List<(Int32 X, Int32 Y)> e = new List<(int X, int Y)>();
            for (Int32 i = 0; i < _gameBoard.GetLength(0); ++i)
            {
                for (Int32 j = 0; j < _gameBoard.GetLength(1); ++j)
                {
                    if (_gameBoard[i, j] == Entity.Enemy)
                    {
                        e.Add((i, j));
                    }
                }
            }
            return e;
        }

        private void CheckStep(Int32 x, Int32 y)
        {
            if (x < 0 || x >= _gameBoard.GetLength(0))
                throw new ArgumentOutOfRangeException("x", "Bad column index.");
            if (y < 0 || y >= _gameBoard.GetLength(1))
                throw new ArgumentOutOfRangeException("y", "Bad row index.");
        }

        #endregion
    }
}
