﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Threading;
using Escape.Model;
using Escape.Persistence;

namespace Escape.ViewModel
{
    public class EscapeViewModel  : ViewModelBase
    {

        #region Fields

        private EscapeGameModel _model;

        #endregion

        #region Properties

        public DelegateCommand NewGameSmallCommand { get; private set; }
        public DelegateCommand NewGameMediumCommand { get; private set; }
        public DelegateCommand NewGameLargeCommand { get; private set; }
        public DelegateCommand PauseGameCommand { get; private set; }
        public DelegateCommand LoadGameCommand { get; private set; }

        public DelegateCommand SaveGameCommand { get; private set; }

        public DelegateCommand ExitCommand { get; private set; }

        public ObservableCollection<EscapeField> Fields { get; set; }

        public String GameTime { get { return TimeSpan.FromSeconds(_model.GameTime).ToString("g"); } }

        public Int32 BoardSize
        {
            get { return _model.BoardSize; }
            set
            {
                if (_model.BoardSize != value)
                {
                    _model.BoardSize = value;
                    OnPropertyChanged();
                }
            }
        }

        #endregion

        #region Events

        public event EventHandler NewGameSmall;
        public event EventHandler NewGameMedium;
        public event EventHandler NewGameLarge;

        public event EventHandler PauseGame;
        public event EventHandler LoadGame;
        public event EventHandler SaveGame;

        public event EventHandler ExitGame;

        #endregion

        #region Constructors

        public EscapeViewModel(EscapeGameModel model)
        {
            _model = model;
            _model.GameOver += new EventHandler<EscapeEventArgs>(Model_GameOver);
            _model.BoardChanged += new EventHandler<EscapeEventArgs>(Model_BoardChanged);
            _model.TimeAdvanced += new EventHandler<EscapeEventArgs>(Model_TimeAdvanced);
            _model.GameCreated += new EventHandler<EscapeEventArgs>(Model_GameCreated);

            NewGameSmallCommand = new DelegateCommand(param => OnNewGameSmall());
            NewGameMediumCommand = new DelegateCommand(param => OnNewGameMedium());
            NewGameLargeCommand = new DelegateCommand(param => OnNewGameLarge());

            PauseGameCommand = new DelegateCommand(param => OnPauseGame());
            LoadGameCommand = new DelegateCommand(param => OnLoadGame());
            SaveGameCommand = new DelegateCommand(param => OnSaveGame());
            ExitCommand = new DelegateCommand(param => OnExitGame());

            Fields = new ObservableCollection<EscapeField>();
        }

        #endregion

        #region Private methods
        private void GenerateFields()
        {
            Fields.Clear();
            for (Int32 i = 0; i < BoardSize; i++)
            {
                for (Int32 j = 0; j < BoardSize; j++)
                {
                    Fields.Add(new EscapeField
                    {
                        X = j,
                        Y = i,
                        IsPlayer = _model.Board[i, j] == Entity.Player ? true : false,
                        IsEnemy = _model.Board[i, j] == Entity.Enemy ? true : false,
                        IsBomb = _model.Board[i, j] == Entity.Bomb ? true : false,
                    });
                }
            }
            Model_BoardChanged(null, null);
        }

        #endregion

        #region Model event handlers

        private void Model_BoardChanged(object sender, EscapeEventArgs e)
        {
            foreach (EscapeField field in Fields)
            {
                field.IsPlayer = _model.Board[field.X, field.Y] == Entity.Player ? true : false;
                field.IsEnemy = _model.Board[field.X, field.Y] == Entity.Enemy ? true : false;
                field.IsBomb = _model.Board[field.X, field.Y] == Entity.Bomb ? true : false;
            }
            OnPropertyChanged("Fields");
        }

        private void Model_GameOver(object sender, EscapeEventArgs e)
        {
            foreach (EscapeField field in Fields)
            {
                field.IsPlayer = false;
                field.IsEnemy = false;
                field.IsBomb = false;
            }
            OnPropertyChanged("Fields");
        }

        private void Model_TimeAdvanced(object sender, EscapeEventArgs e)
        {
            OnPropertyChanged("GameTime");
        }

        private void Model_GameCreated(object sender, EscapeEventArgs e)
        {
            GenerateFields();
            OnPropertyChanged("BoardSize");
            OnPropertyChanged("GameTime");
            Model_BoardChanged(null, null);
        }

        #endregion

        #region Event methods

        private void OnNewGameSmall()
        {
            if (NewGameSmall != null)
                NewGameSmall(this, EventArgs.Empty);
        }

        private void OnNewGameMedium()
        {
            if (NewGameMedium != null)
                NewGameMedium(this, EventArgs.Empty);
        }

        private void OnNewGameLarge()
        {
            if (NewGameLarge != null)
                NewGameLarge(this, EventArgs.Empty);
        }

        private void OnPauseGame()
        {
            if (PauseGame != null)
                PauseGame(this, EventArgs.Empty);
        }

        private void OnLoadGame()
        {
            if (LoadGame != null)
                LoadGame(this, EventArgs.Empty);
        }

        private void OnSaveGame()
        {
            if (SaveGame != null)
                SaveGame(this, EventArgs.Empty);
        }

        private void OnExitGame()
        {
            if (ExitGame != null)
                ExitGame(this, EventArgs.Empty);
        }

        #endregion
    }
}
