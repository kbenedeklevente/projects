﻿using System;
using System.Collections.Generic;
using System.Text;
using Escape.Persistence;

namespace Escape.ViewModel
{
    public class EscapeField : ViewModelBase
    {
        private Boolean _isPlayer;
        private Boolean _isEnemy;
        private Boolean _isBomb;
        private Int32 _x;
        private Int32 _y;

        public Int32 X 
        { 
            get { return _x; }
            set
            {
                if(_x != value)
                {
                    _x = value;
                    OnPropertyChanged();
                }
            }
        }

        public Int32 Y
        {
            get { return _y; }
            set
            {
                if (_y != value)
                {
                    _y = value;
                    OnPropertyChanged();
                }
            }
        }

        public Boolean IsPlayer
        {
            get { return _isPlayer; }
            set
            {
                if (_isPlayer != value)
                {
                    _isPlayer = value;
                    OnPropertyChanged();
                }
            }
        }

        public Boolean IsEnemy
        {
            get { return _isEnemy; }
            set
            {
                if (_isEnemy != value)
                {
                    _isEnemy = value;
                    OnPropertyChanged();
                }
            }
        }

        public Boolean IsBomb
        {
            get { return _isBomb; }
            set
            {
                if (_isBomb != value)
                {
                    _isBomb = value;
                    OnPropertyChanged();
                }
            }
        }
    }
}
