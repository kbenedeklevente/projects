export class Field {
    treasure = -1;
    doors = [0,0,0,0];
    rotated = 0;
    img = "";
    fixed = false;

    rotate(r) {
        for(let i = 0; i < r; i++){
            let last;    
            last = this.doors[this.doors.length-1];    
            for(let j = this.doors.length-1; j > 0; j--){     
                this.doors[j] = this.doors[j-1];    
            }
            this.doors[0] = last;    
        }
        this.rotated += r;
    }
}