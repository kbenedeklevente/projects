import { Field } from "./field.js"
import { Player } from "./player.js"

//door values
let straight = [1,0,1,0];
let curve = [0,1,1,0];
let triway = [1,1,1,0];
let playerStart= [[0,0],[0,6],[6,0],[6,6]]

export class AppState {
    board = [7][7];
    extraField = new Field();
    players = [];
    currentPlayer = 0;

    init(playerCount, treasureCount) {
        this.board = [];
        for(let y = 0; y < 7; y++){
            this.board[y] = [];
            for(let x = 0; x < 7; x++){
                this.board[y][x] = new Field();
            }
        }
        
        this.setFixedFields();

        this.setUnfixedFields();

        this.extraField.doors = [...triway];
        this.extraField.img = "triway";

        for(let i = 0; i < playerCount; i++){
            this.players[i] = new Player();
            this.players[i].startPos = [...playerStart[i]];
            this.players[i].currentPos = [...playerStart[i]];
            this.players[i].playerID = i;
        }

        let treasures = [];
        for(let i = 0; i < treasureCount*playerCount; i++){
            let tr;
            do{
            tr = Math.floor(Math.random() * treasureCount * playerCount);
            }while(treasures.includes(tr));
            treasures.push(tr);
            const {x, y} = this.getEmptyCoords();
            this.board[y][x].treasure = tr;
            let p;
            do{
                p = Math.floor(Math.random() * playerCount);
            }while(this.players[p].toGet.length>=treasureCount);
            this.players[p].toGet.push(tr);
        }
    }

    rotateExtraField(){
        this.extraField.rotate(1);
    }

    playerWon(playerID){
        const missing = this.players[playerID].toGet.filter(e => !this.players[playerID].obtained.includes(e));
        if(missing.length === 0 && this.players[playerID].startPos[0] === this.players[playerID].currentPos[0] && this.players[playerID].startPos[1] === this.players[playerID].currentPos[1])
            return true;
        return false;
    }

    stepPlayer(playerID, y, x){
        this.players[playerID].currentPos[0] = y;
        this.players[playerID].currentPos[1] = x;
        if(this.players[playerID].toGet[0] == this.board[y][x].treasure){
            this.board[y][x].treasure = -1;
            this.players[playerID].obtained.push(this.players[playerID].toGet.shift());
        }
    }

    isMoveValid(playerID, y, x){
        let pY = this.players[playerID].currentPos[0];
        let pX = this.players[playerID].currentPos[1];
        if(y <= 6 && y >= 0 && x <= 6 && x >= 0){
            if(pY+1 == y &&  pX == x && this.openDoors(pY,pX)[2] == 1)
                return true;
            else if(pY-1 == y &&  pX == x && this.openDoors(pY,pX)[0] == 1)
                return true;
            else if(pX+1 == x && pY == y && this.openDoors(pY,pX)[1] == 1)
                return true;
            else if(pX-1 == x && pY == y && this.openDoors(pY,pX)[3] == 1)
                return true;
            return false;
        }
        return false;
    }

    allOpenRooms(y, x) {
        var roomArray = Array(7).fill().map(()=>Array(7).fill(0))
        roomArray[y][x] = 1;
        let newRoomExplored = true;
        while(newRoomExplored){
            newRoomExplored = false;
            for(let i = 0; i < 7; i++){
                for(let j = 0; j < 7; j++){
                    if(roomArray[j][i] == 1){
                        if(this.openDoors(j, i)[0] == 1 && roomArray[j-1][i] != 1){
                            roomArray[j-1][i] = 1;
                            newRoomExplored = true;
                        }
                        if(this.openDoors(j, i)[1] == 1 && roomArray[j][i+1] != 1){
                            roomArray[j][i+1] = 1;
                            newRoomExplored = true;
                        }
                        if(this.openDoors(j, i)[2] == 1 && roomArray[j+1][i] != 1){
                            roomArray[j+1][i] = 1;
                            newRoomExplored = true;
                        }
                        if(this.openDoors(j, i)[3] == 1 && roomArray[j][i-1] != 1){
                            roomArray[j][i-1] = 1;
                            newRoomExplored = true;
                        }
                    }
                }
            }
        }

        return roomArray;
    }

    openDoors(y, x){
        let openDoors = [];
        //up
        if(y-1 >= 0){
            if(this.board[y][x].doors[0] == 1 && this.board[y-1][x].doors[2] == 1) 
                openDoors.push(1);
            else openDoors.push(0);
        } else openDoors.push(0);
        //right
        if(x+1 <= 6){
            if(this.board[y][x].doors[1] == 1 && this.board[y][x+1].doors[3] == 1) 
                openDoors.push(1);
            else openDoors.push(0);
        } else openDoors.push(0);
        //down
        if(y+1 <= 6){
            if(this.board[y][x].doors[2] == 1 && this.board[y+1][x].doors[0] == 1) 
                openDoors.push(1);
            else openDoors.push(0);
        } else openDoors.push(0);
        //left
        if(x-1 >= 0){
            if(this.board[y][x].doors[3] == 1 && this.board[y][x-1].doors[1] == 1) 
                openDoors.push(1);
            else openDoors.push(0);
        } else openDoors.push(0);
        return openDoors;
    }

    slidePlayers(colIndex, rowIndex, direction){
        let playerIDs = this.playersInRowOrCol(colIndex, rowIndex);
        if(rowIndex != -1){
            [...playerIDs].forEach(id => {
                if(this.players[id].currentPos[0] + direction >= 0 && this.players[id].currentPos[0] + direction <= 6){
                    this.players[id].currentPos[0] += direction;
                }
                else if(this.players[id].currentPos[0] + direction < 0){
                    this.players[id].currentPos[0] = 6;
                }
                else if(this.players[id].currentPos[0] + direction > 6){
                    this.players[id].currentPos[0] = 0;
                }
            });
        }
        else if(colIndex != -1){
            [...playerIDs].forEach( id => {
                if(this.players[id].currentPos[1] + direction >= 0 && this.players[id].currentPos[1] + direction <= 6){
                    this.players[id].currentPos[1] += direction;
                }
                else if(this.players[id].currentPos[1] + direction < 0){
                    this.players[id].currentPos[1] = 6;
                }
                else if(this.players[id].currentPos[1] + direction > 6){
                    this.players[id].currentPos[1] = 0;
                }
            });
        }
    }

    playersInRowOrCol(colIndex, rowIndex){
        let here = [];
        for(let i = 0; i < this.players.length; i++){
            if(this.players[i].currentPos[0] == colIndex || this.players[i].currentPos[1] == rowIndex){
                here.push(i);
            }
        }
        return here;
    }

    slideRow(y, d){
        if(y != -1){  
            if(d == 1){        
                let tmp = new Field();
                tmp = this.board[y][6];
                //tmp.rotate(this.board[y][6].rotated);
                for(let x = 6; x > 0; x--){
                    this.board[y][x] = this.board[y][x-1];
                }
                this.board[y][0] = this.extraField;
                //this.board[y][0].rotate(this.extraField.rotated);
                this.extraField = tmp;
            }
            else if(d == -1){
                let tmp = new Field();
                tmp = this.board[y][0];
                //tmp.rotate(this.board[y][0].rotated);
                for(let x = 0; x < 6; x++){
                    this.board[y][x] = this.board[y][x+1];
                }
                this.board[y][6] = this.extraField;
                //this.board[y][6].rotate(this.extraField.rotated);
                this.extraField = tmp;
            }
        }
    }

    slideColumn(x, d){
        if(x != -1){  
            if(d == 1){
                let tmp = new Field();
                tmp = this.board[6][x];
                //tmp.rotate(this.board[6][x].rotated);
                for(let y = 6; y > 0; y--){
                    this.board[y][x] = this.board[y-1][x];
                }
                this.board[0][x] = this.extraField;
                //this.board[0][x].rotate(this.extraField.rotated);
                this.extraField = tmp;
                
            }
            else if(d == -1){
                let tmp = new Field();
                tmp = this.board[0][x];
                //tmp.rotate(this.board[0][x].rotated);
                for(let y = 0; y < 6; y++){
                    this.board[y][x] = this.board[y+1][x];
                }
                this.board[6][x] = this.extraField;
                //this.board[6][x].rotate(this.extraField.rotated);
                this.extraField = tmp;
            }
        }
    }

    getEmptyCoords(){
        let x, y;
        do{
            x = Math.floor(Math.random() * 7);
            y = Math.floor(Math.random() * 7);
        }while(this.board[y][x].treasure != -1 || ((x==0 && y==0) 
                                               || (x==0 && y==6) 
                                               || (x==6 && y==0)
                                               || (x==6 && y==6)));
        return {x, y};
    }

    setUnfixedFields(){
        let count = [13, 15, 6];
        let type, r;
        for(let y = 0; y < 7; y++){
            for(let x = 0; x < 7; x++){
                if(!this.board[y][x].fixed){

                    do{
                        type = Math.floor(Math.random() * 3);
                    }while(count[type] == 0);

                    count[type]--;

                    r = Math.floor(Math.random() * 4);

                    if(type==0){
                        this.board[y][x].doors = [...straight];
                        this.board[y][x].img = "straight";
                    } else if(type==1){
                        this.board[y][x].doors = [...curve];
                        this.board[y][x].img = "curve";
                    } else {
                        this.board[y][x].doors = [...triway];
                        this.board[y][x].img = "triway";
                    }
                    this.board[y][x].rotate(r);
                    }
                }
        }
    }

    setFixedFields(){
        //0th row
        this.board[0][0].doors = [...curve];
        this.board[0][0].img = "curve";
        this.board[0][0].fixed = true;
        this.board[0][0].rotate(0);

        this.board[0][2].doors = [...triway];
        this.board[0][2].img = "triway";
        this.board[0][2].fixed = true;
        this.board[0][2].rotate(1);

        this.board[0][4].doors = [...triway];
        this.board[0][4].img = "triway";
        this.board[0][4].fixed = true;
        this.board[0][4].rotate(1);

        this.board[0][6].doors = [...curve];
        this.board[0][6].img = "curve";
        this.board[0][6].fixed = true;
        this.board[0][6].rotate(1);

        //2nd row
        this.board[2][0].doors = [...triway];
        this.board[2][0].img = "triway";
        this.board[2][0].fixed = true;
        this.board[2][0].rotate(0);

        this.board[2][2].doors = [...triway];
        this.board[2][2].img = "triway";
        this.board[2][2].fixed = true;
        this.board[2][2].rotate(0);

        this.board[2][4].doors = [...triway];
        this.board[2][4].img = "triway";
        this.board[2][4].fixed = true;
        this.board[2][4].rotate(1);

        this.board[2][6].doors = [...triway];
        this.board[2][6].img = "triway";
        this.board[2][6].fixed = true;
        this.board[2][6].rotate(2);

        //4rd row
        this.board[4][0].doors = [...triway];
        this.board[4][0].img = "triway";
        this.board[4][0].fixed = true;
        this.board[4][0].rotate(0);

        this.board[4][2].doors = [...triway];
        this.board[4][2].img = "triway";
        this.board[4][2].fixed = true;
        this.board[4][2].rotate(3);

        this.board[4][4].doors = [...triway];
        this.board[4][4].img = "triway";
        this.board[4][4].fixed = true;
        this.board[4][4].rotate(2);

        this.board[4][6].doors = [...triway];
        this.board[4][6].img = "triway";
        this.board[4][6].fixed = true;
        this.board[4][6].rotate(2);

        //6th row
        this.board[6][0].doors = [...curve];
        this.board[6][0].img = "curve";
        this.board[6][0].fixed = true;
        this.board[6][0].rotate(3);

        this.board[6][2].doors = [...triway];
        this.board[6][2].img = "triway";
        this.board[6][2].fixed = true;
        this.board[6][2].rotate(3);

        this.board[6][4].doors = [...triway];
        this.board[6][4].img = "triway";
        this.board[6][4].fixed = true;
        this.board[6][4].rotate(3);

        this.board[6][6].doors = [...curve];
        this.board[6][6].img = "curve";
        this.board[6][6].fixed = true;
        this.board[6][6].rotate(2);
    }
}