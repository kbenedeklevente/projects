export class Player {
    playerID = -1;
    startPos = [-1,-1]
    currentPos = [-1, -1];
    toGet = [];
    obtained = [];
}