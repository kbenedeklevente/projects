const canvas = document.querySelector('canvas')
const ctx = canvas.getContext('2d')

let boardSize = 7;
let fieldSize = 50;
let border = fieldSize / 20;
let offSet = fieldSize;
export let efCurrX = 500;
export let efCurrY = 200;

export function moveExtraField(state, toX, toY, joe = 0){
    ctx.clearRect(0,0,canvas.width, canvas.height);
    renderFields(state);
    renderPlayers(state);
    let posX = efCurrX + (toX - efCurrX)/50*joe;
    let posY = efCurrY + (toY - efCurrY)/50*joe;
    renderExtraField(state, posX, posY);
    joe +=2;
    if(joe <= 50){
        window.requestAnimationFrame(function(){
            moveExtraField(state, toX, toY , joe);
        });
    }
    else{
        renderFields(state);
        renderPlayers(state);
        renderExtraField(state, toX, toY);
    }
}

export function movePlayer(state, playerID, x, y, pixels = 0){
    if(state.isMoveValid(playerID, y, x)){
        ctx.clearRect(0,0,canvas.width, canvas.height);
        renderFields(state);
        renderPlayers(state, x, y, pixels, playerID);
        renderExtraField(state);
        pixels += 5;
        if(pixels <= fieldSize){
            window.requestAnimationFrame(function(){
                movePlayer(state, playerID, x, y, pixels);
            });
        }
        else{
            state.stepPlayer(playerID, y, x);
            renderFields(state);
            renderPlayers(state);
            renderExtraField(state);
        }
    }
}

export function slideFields(state, colIndex, rowIndex, direction, pixels = 0) {
    ctx.clearRect(0,0,canvas.width, canvas.height);
    if(pixels == 0){
        state.slideRow(rowIndex, direction);
        state.slideColumn(colIndex, direction);
        state.slidePlayers(rowIndex, colIndex, direction);
        if(direction > 0){
            if(colIndex > 0){
                renderExtraField(state, 50*(colIndex+1), 50*7);
            }
            else{
                renderExtraField(state, 50*7, 50*(rowIndex+1));
            }
        }
        else {
            if(colIndex > 0){
                renderExtraField(state, 50*(colIndex+1), 50);
            }
            else{
                renderExtraField(state, 50, 50*(rowIndex+1));
                
            }
        }
        moveExtraField(state, 500, 200);
    }

    renderFields(state, colIndex, rowIndex, pixels*direction-50*direction);
    renderPlayers(state, colIndex, rowIndex, pixels*direction-50*direction);
    renderExtraField(state);
    pixels += 5;
    if(pixels <=fieldSize){
        window.requestAnimationFrame(function(){
            slideFields(state, colIndex, rowIndex, direction, pixels)
        });
    }
    else{
        renderFields(state);
        renderPlayers(state);
        renderExtraField(state);
    }
}

export function renderExtraField(state, posX = efCurrX, posY = efCurrY){
    ctx.save();
    efCurrX = posX;
    efCurrY = posY;
    if(state.extraField.img == "straight"){
        if(state.extraField.rotated == 0) {
            ctx.drawImage(straight, posX, posY);
        }
        else {
            ctx.translate(posX+fieldSize/2, posY+fieldSize/2);
            ctx.rotate(state.extraField.rotated*Math.PI*2/4);
            ctx.drawImage(straight, -fieldSize/2, -fieldSize/2);
        }
    }
    else if(state.extraField.img == "curve"){
        if(state.extraField.rotated == 0) {
            ctx.drawImage(curve, posX, posY);
        }
        else {

            ctx.translate(posX+fieldSize/2, posY+fieldSize/2);
            ctx.rotate(state.extraField.rotated*Math.PI*2/4);
            ctx.drawImage(curve, -fieldSize/2, -fieldSize/2);
        }
    }
    else if(state.extraField.img == "triway"){
        if(state.extraField.rotated == 0) {
            ctx.drawImage(triway, posX, posY);
        }
        else {
            ctx.translate(posX+fieldSize/2, posY+fieldSize/2);
            ctx.rotate(state.extraField.rotated*Math.PI*2/4);
            ctx.drawImage(triway, -fieldSize/2, -fieldSize/2);
        }
    }
    ctx.restore();
    if(state.extraField.treasure != -1){
        ctx.drawImage(treasure, posX+fieldSize/3, posY+fieldSize/3);
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = '15px anton';
        ctx.fillText (state.extraField.treasure, posX+fieldSize/3 + treasure.width/2, posY+fieldSize/3 +treasure.height/2);
    }
}

export function markFields(state, y, x){
    ctx.globalAlpha = 0.1;
    ctx.fillStyle = "green";
    let rooms = state.allOpenRooms(y, x);
    for(let i = 0; i < 7; i++){
        for(let j = 0; j < 7; j++){
            if(rooms[j][i] == 1){
                ctx.beginPath();
                ctx.globalAlpha = 0.2;
                ctx.rect(fieldSize * (i + 1), fieldSize * (j + 1), fieldSize, fieldSize);
                ctx.fill();
                ctx.closePath();
            }
        }
    }
    ctx.globalAlpha = 1;
    ctx.fillStyle = "black";
}

export function renderFields(state, colIndex = -1,rowIndex = -1, px = 0) {
    ctx.clearRect(0,0,canvas.width, canvas.height);
    let col = (colIndex >= 0) ? 1 : 0;
    let row = (rowIndex >= 0) ? 1 : 0;
    for(let y = 0; y < 7; y++){
        for(let x = 0; x < 7; x++){
            if(x == colIndex){
                if((!(y == 6 || x == 6)) || (!(y == 0 || x == 0))){
                    renderField(state.board[y][x], y, x, col, row, px);
                }
            }
            else if(y == rowIndex){
                if((!(y == 6 || x == 6)) || (!(y == 0 || x == 0)))
                    renderField(state.board[y][x], y, x, col, row, px);
            }
            else{
                renderField(state.board[y][x], y, x);
            }
        }
    }
    renderArrows();
    markFields(state, state.players[state.currentPlayer].currentPos[0], state.players[state.currentPlayer].currentPos[1]);
}

function animatePlayerMove(state, playerID, y , x, px){
    if(playerID == 0){
        if(y < state.players[playerID].currentPos[0] && x == state.players[playerID].currentPos[1])
            ctx.drawImage(player0C, x*fieldSize+border+offSet, (y+1)*fieldSize+border-px+offSet);
        else if(y == state.players[playerID].currentPos[0] && x > state.players[playerID].currentPos[1])
            ctx.drawImage(player0C, (x-1)*fieldSize+border+px+offSet, y*fieldSize+border+offSet);
        else if(y > state.players[playerID].currentPos[0] && x == state.players[playerID].currentPos[1])
            ctx.drawImage(player0C, x*fieldSize+border+offSet, (y-1)*fieldSize+border+px+offSet);
        else if(y == state.players[playerID].currentPos[0] && x < state.players[playerID].currentPos[1])
            ctx.drawImage(player0C, (x+1)*fieldSize+border-px+offSet, y*fieldSize+border+offSet);
    }
    else if(playerID == 1){
        if(y < state.players[playerID].currentPos[0] && x == state.players[playerID].currentPos[1])
            ctx.drawImage(player1C, x*fieldSize-border+(fieldSize-player.width)+offSet, (y+1)*fieldSize+border-px+offSet);
        else if(y == state.players[playerID].currentPos[0] && x > state.players[playerID].currentPos[1])
            ctx.drawImage(player1C, (x-1)*fieldSize-border+(fieldSize-player.width)+px+offSet, y*fieldSize+border+offSet);
        else if(y > state.players[playerID].currentPos[0] && x == state.players[playerID].currentPos[1])
            ctx.drawImage(player1C, x*fieldSize-border+(fieldSize-player.width)+offSet, (y-1)*fieldSize+border+px+offSet);
        else if(y == state.players[playerID].currentPos[0] && x < state.players[playerID].currentPos[1])
            ctx.drawImage(player1C, (x+1)*fieldSize-border+(fieldSize-player.width)-px+offSet, y*fieldSize+border+offSet);
    }
    else if(playerID == 2){
        if(y < state.players[playerID].currentPos[0] && x == state.players[playerID].currentPos[1])
            ctx.drawImage(player2C, x*fieldSize+border+offSet, (y+1)*fieldSize-border+(fieldSize-player.width)-px+offSet);
        else if(y == state.players[playerID].currentPos[0] && x > state.players[playerID].currentPos[1])
            ctx.drawImage(player2C, (x-1)*fieldSize+border+px+offSet, y*fieldSize-border+(fieldSize-player.width)+offSet);
        else if(y > state.players[playerID].currentPos[0] && x == state.players[playerID].currentPos[1])
            ctx.drawImage(player2C, x*fieldSize+border+offSet, (y-1)*fieldSize-border+(fieldSize-player.width)+px+offSet);
        else if(y == state.players[playerID].currentPos[0] && x < state.players[playerID].currentPos[1])
            ctx.drawImage(player2C, (x+1)*fieldSize+border-px+offSet, y*fieldSize-border+(fieldSize-player.width)+offSet);
    }
    else if(playerID == 3){
        if(y < state.players[playerID].currentPos[0] && x == state.players[playerID].currentPos[1])
            ctx.drawImage(player3C, x*fieldSize-border+(fieldSize-player.width)+offSet, (y+1)*fieldSize-border+(fieldSize-player.width)-px+offSet);
        else if(y == state.players[playerID].currentPos[0] && x > state.players[playerID].currentPos[1])
            ctx.drawImage(player3C,(x-1)*fieldSize-border+(fieldSize-player.width)+px+offSet, y*fieldSize-border+(fieldSize-player.width)+offSet);
        else if(y > state.players[playerID].currentPos[0] && x == state.players[playerID].currentPos[1])
            ctx.drawImage(player3C, x*fieldSize-border+(fieldSize-player.width)+offSet, (y-1)*fieldSize-border+(fieldSize-player.width)+px+offSet);
        else if(y == state.players[playerID].currentPos[0] && x < state.players[playerID].currentPos[1])
            ctx.drawImage(player3C, (x+1)*fieldSize-border+(fieldSize-player.width)-px+offSet, y*fieldSize-border+(fieldSize-player.width)+offSet);
    }
}

export function renderPlayers(state, colIndex = -1, rowIndex = -1, px = 0, playerID = -1) {
    for(let i = 0; i < state.players.length; i++){
        if(state.players[i].playerID != playerID){
            let y = state.players[i].currentPos[0];
            let x = state.players[i].currentPos[1];
            if(state.players[i].playerID == 0){
                if(state.currentPlayer == 0){
                    if(x==colIndex && rowIndex == -1)
                        ctx.drawImage(player0C, x*fieldSize+border+offSet, y*fieldSize+border+px+offSet);
                    else if(y==rowIndex && colIndex == -1)
                        ctx.drawImage(player0C, x*fieldSize+border+px+offSet, y*fieldSize+border+offSet);
                    else
                        ctx.drawImage(player0C, x*fieldSize+border+offSet, y*fieldSize+border+offSet);
                }
                else{
                    if(x==colIndex && rowIndex == -1)
                        ctx.drawImage(player0, x*fieldSize+border+offSet, y*fieldSize+border+px+offSet);
                    else if(y==rowIndex && colIndex == -1)
                        ctx.drawImage(player0, x*fieldSize+border+px+offSet, y*fieldSize+border+offSet);
                    else
                        ctx.drawImage(player0, x*fieldSize+border+offSet, y*fieldSize+border+offSet);
                }
            }
            else if(state.players[i].playerID == 1){
                if(state.currentPlayer == 1){
                    if(x==colIndex && rowIndex == -1)
                        ctx.drawImage(player1C, x*fieldSize-border+(fieldSize-player.width)+offSet, y*fieldSize+border+px+offSet);
                    else if(y==rowIndex && colIndex == -1)
                        ctx.drawImage(player1C, x*fieldSize-border+(fieldSize-player.width)+px+offSet, y*fieldSize+border+offSet);
                    else
                        ctx.drawImage(player1C, x*fieldSize-border+(fieldSize-player.width)+offSet, y*fieldSize+border+offSet);
                }
                else{
                    if(x==colIndex && rowIndex == -1)
                        ctx.drawImage(player1, x*fieldSize-border+(fieldSize-player.width)+offSet, y*fieldSize+border+px+offSet);
                    else if(y==rowIndex && colIndex == -1)
                        ctx.drawImage(player1, x*fieldSize-border+(fieldSize-player.width)+px+offSet, y*fieldSize+border+offSet);
                    else
                        ctx.drawImage(player1, x*fieldSize-border+(fieldSize-player.width)+offSet, y*fieldSize+border+offSet);
                }
            }
            else if(state.players[i].playerID == 2){
                if(state.currentPlayer == 2){
                    if(x==colIndex && rowIndex == -1)
                        ctx.drawImage(player2C, x*fieldSize+border+offSet, y*fieldSize-border+(fieldSize-player.width)+px+offSet);
                    else if(y==rowIndex && colIndex == -1)
                        ctx.drawImage(player2C, x*fieldSize+border+px+offSet, y*fieldSize-border+(fieldSize-player.width)+offSet);
                    else
                        ctx.drawImage(player2C, x*fieldSize+border+offSet, y*fieldSize-border+(fieldSize-player.width)+offSet);
                }
                else{
                    if(x==colIndex && rowIndex == -1)
                        ctx.drawImage(player2, x*fieldSize+border+offSet, y*fieldSize-border+(fieldSize-player.width)+px+offSet);
                    else if(y==rowIndex && colIndex == -1)
                        ctx.drawImage(player2, x*fieldSize+border+px+offSet, y*fieldSize-border+(fieldSize-player.width)+offSet);
                    else
                        ctx.drawImage(player2, x*fieldSize+border+offSet, y*fieldSize-border+(fieldSize-player.width)+offSet);
                }
            }
            else if(state.players[i].playerID == 3){
                if(state.currentPlayer == 3){
                    if(x==colIndex && rowIndex == -1)
                        ctx.drawImage(player3C, x*fieldSize-border+(fieldSize-player.width)+offSet, y*fieldSize-border+(fieldSize-player.width)+px+offSet);
                    else if(y==rowIndex && colIndex == -1)
                        ctx.drawImage(player3C, x*fieldSize-border+(fieldSize-player.width)+px+offSet, y*fieldSize-border+(fieldSize-player.width)+offSet);
                    else
                        ctx.drawImage(player3C, x*fieldSize-border+(fieldSize-player.width)+offSet, y*fieldSize-border+(fieldSize-player.width)+offSet);
                    }
                else{
                    if(x==colIndex && rowIndex == -1)
                        ctx.drawImage(player3, x*fieldSize-border+(fieldSize-player.width)+offSet, y*fieldSize-border+(fieldSize-player.width)+px+offSet);
                    else if(y==rowIndex && colIndex == -1)
                        ctx.drawImage(player3, x*fieldSize-border+(fieldSize-player.width)+px+offSet, y*fieldSize-border+(fieldSize-player.width)+offSet);
                    else
                        ctx.drawImage(player3, x*fieldSize-border+(fieldSize-player.width)+offSet, y*fieldSize-border+(fieldSize-player.width)+offSet);
                }
            }
        }
        else {
            animatePlayerMove(state, playerID, rowIndex, colIndex, px)
        }
    }
}

function renderField(field,y,x,col = 0,row = 0, px = 0){
    ctx.save();
    if(field.img == "straight"){
        if(field.rotated == 0) {
            ctx.drawImage(straight, x*fieldSize+row*px+offSet, y*fieldSize+col*px+offSet);
        }
        else {
            ctx.translate(x*fieldSize+fieldSize/2+row*px+ offSet, y*fieldSize+fieldSize/2+col*px+offSet);
            ctx.rotate(field.rotated*Math.PI*2/4);
            ctx.drawImage(straight, -fieldSize/2, -fieldSize/2);
        }
    }
    else if(field.img == "curve"){
        if(field.rotated == 0) {
            ctx.drawImage(curve, x*fieldSize + row*px +offSet, y*fieldSize + col*px+offSet);
        }
        else {

            ctx.translate(x*fieldSize+fieldSize/2+row*px+offSet, y*fieldSize+fieldSize/2+col*px+offSet);
            ctx.rotate(field.rotated*Math.PI*2/4);
            ctx.drawImage(curve, -fieldSize/2, -fieldSize/2);
        }
    }
    else if(field.img == "triway"){
        if(field.rotated == 0) {
            ctx.drawImage(triway, x*fieldSize + row*px+offSet, y*fieldSize  + col*px+offSet);
        }
        else {
            ctx.translate(x*fieldSize+fieldSize/2+row*px+offSet, y*fieldSize+fieldSize/2+col*px+offSet);
            ctx.rotate(field.rotated*Math.PI*2/4);
            ctx.drawImage(triway, -fieldSize/2, -fieldSize/2);
        }
    }
    ctx.restore();
    if(field.treasure != -1){
        ctx.drawImage(treasure, x*fieldSize+fieldSize/3 + row*px+offSet, y*fieldSize+fieldSize/3  + col*px+offSet);
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = '15px anton';
        ctx.fillText (field.treasure, x*fieldSize+fieldSize/3 + treasure.width/2 + row*px+offSet, y*fieldSize+fieldSize/3 +treasure.height/2 + col*px+offSet);
    }
}

function renderArrows(){
    ctx.drawImage(arrow, 100, 0);
    ctx.drawImage(arrow, 200, 0);
    ctx.drawImage(arrow, 300, 0);

    ctx.save();
    ctx.translate(400 + fieldSize/2, 100+fieldSize/2);
    ctx.rotate(1*Math.PI*2/4);
    ctx.drawImage(arrow, -fieldSize/2, -fieldSize/2);
    ctx.restore();

    ctx.save();
    ctx.translate(400 + fieldSize/2, 200+fieldSize/2);
    ctx.rotate(1*Math.PI*2/4);
    ctx.drawImage(arrow, -fieldSize/2, -fieldSize/2);
    ctx.restore();

    ctx.save();
    ctx.translate(400 + fieldSize/2, 300+fieldSize/2);
    ctx.rotate(1*Math.PI*2/4);
    ctx.drawImage(arrow, -fieldSize/2, -fieldSize/2);
    ctx.restore();

    ctx.save();
    ctx.translate(100 + fieldSize/2, 400+fieldSize/2);
    ctx.rotate(2*Math.PI*2/4);
    ctx.drawImage(arrow, -fieldSize/2, -fieldSize/2);
    ctx.restore();

    ctx.save();
    ctx.translate(200 + fieldSize/2, 400+fieldSize/2);
    ctx.rotate(2*Math.PI*2/4);
    ctx.drawImage(arrow, -fieldSize/2, -fieldSize/2);
    ctx.restore();

    ctx.save();
    ctx.translate(300 + fieldSize/2, 400+fieldSize/2);
    ctx.rotate(2*Math.PI*2/4);
    ctx.drawImage(arrow, -fieldSize/2, -fieldSize/2);
    ctx.restore();

    ctx.save();
    ctx.translate(0 + fieldSize/2, 100+fieldSize/2);
    ctx.rotate(3*Math.PI*2/4);
    ctx.drawImage(arrow, -fieldSize/2, -fieldSize/2);
    ctx.restore();

    ctx.save();
    ctx.translate(0 + fieldSize/2, 200+fieldSize/2);
    ctx.rotate(3*Math.PI*2/4);
    ctx.drawImage(arrow, -fieldSize/2, -fieldSize/2);
    ctx.restore();

    ctx.save();
    ctx.translate(0 + fieldSize/2, 300+fieldSize/2);
    ctx.rotate(3*Math.PI*2/4);
    ctx.drawImage(arrow, -fieldSize/2, -fieldSize/2);
    ctx.restore();
}