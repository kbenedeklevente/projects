import { AppState } from "./state.js";
import { renderFields, slideFields, renderPlayers, movePlayer, renderExtraField, moveExtraField, markFields, efCurrY, efCurrX} from "./render.js"

let state = new AppState();

let hasMovedField = false;
console.log(state);


function gameTurn(){
    hasMovedField = false;
    canvas.addEventListener('mousemove', canvasHover);
    state.currentPlayer = state.currentPlayer == state.players.length - 1 ? 0 : state.currentPlayer + 1;
    updateInfo();
}

function updateInfo(){
    currentPlayer.innerHTML = state.currentPlayer + 1 + " játékos köre";
    if(state.players[state.currentPlayer].toGet.length != 0)
        toGet.innerHTML = "Keresett kincs: " + state.players[state.currentPlayer].toGet[0].toString();
    else
        toGet.innerHTML = "Térj vissza a kezdő mezőre!";
    obtained.innerHTML = "Megszerzett kincsek: " + state.players[state.currentPlayer].obtained.length + "/" + treasureCount.value;
}

reset.addEventListener('click', function(event){
    location.reload();
    startMenu.style.display = "block";
    game.style.display = "none";
});

newGame.addEventListener('click', function(event){
    location.reload();
    game.style.display = "none";
    startMenu.style.display = "block";
    gameOver.style.display = "none";
});

nextTurn.addEventListener('click', function(event){
    gameTurn();
    renderFields(state);
    renderPlayers(state);
    renderExtraField(state);
});

help.addEventListener('click', function(event){
    description.style.display = "block";
    startMenu.style.display = "none";
});

back.addEventListener('click', function(event){
    description.style.display = "none";
    startMenu.style.display = "block";
});

start.addEventListener('click', function(event){
    state.init(Number(playerCount.value), Number(treasureCount.value));
    updateInfo();
    startMenu.style.display = "none";
    game.style.display = "block";
    renderFields(state);
    renderPlayers(state);
    renderExtraField(state);
    canvas.addEventListener('mousemove', canvasHover)
});

playerCount.addEventListener('input', function(event){
    playerCountLabel.innerHTML = "Játékos szám: " + this.value;
    treasureCount.max = 24 / Number(this.value);
    treasureCount.value = 2;
    treasureCountLabel.innerHTML = "Kincs szám: 2";
});

treasureCount.addEventListener('input', function(event){
    treasureCountLabel.innerHTML = "Kincs szám: " + this.value;
});

canvas.addEventListener('click', function(event) {
    const rect = canvas.getBoundingClientRect();
    const elementRelativeX = event.clientX - rect.left;
    const elementRelativeY = event.clientY - rect.top;
    const canvasRelativeX = elementRelativeX * canvas.width / rect.width;
    const canvasRelativeY = elementRelativeY * canvas.height / rect.height;
    let X = parseInt(canvasRelativeX/50, 10);
    let Y = parseInt(canvasRelativeY/50, 10);
    if(!hasMovedField){
        if(X == 2 && Y == 0){
            slideFields(state, 1, -1, 1);
            hasMovedField = true;
            canvas.removeEventListener('mousemove', canvasHover);
        }
        else if(X == 4 && Y == 0){
            slideFields(state,3, -1, 1);
            hasMovedField = true;
            canvas.removeEventListener('mousemove', canvasHover);
        }
        else if(X == 6 && Y == 0){
            slideFields(state,5, -1, 1);
            hasMovedField = true;
            canvas.removeEventListener('mousemove', canvasHover);
        }
        else if(X == 8 && Y == 2){
            slideFields(state, -1, 1, -1);
            hasMovedField = true;
            canvas.removeEventListener('mousemove', canvasHover);
        }
        else if(X == 8 && Y == 4){
            slideFields(state, -1, 3, -1);
            hasMovedField = true;
            canvas.removeEventListener('mousemove', canvasHover);
        }
        else if(X == 8 && Y == 6){
            slideFields(state, -1, 5, -1);
            hasMovedField = true;
            canvas.removeEventListener('mousemove', canvasHover);
        }
        else if(X == 2 && Y == 8){
            slideFields(state, 1, -1, -1);
            hasMovedField = true;
            canvas.removeEventListener('mousemove', canvasHover);
        }
        else if(X == 4 && Y == 8){
            slideFields(state, 3, -1, -1);
            hasMovedField = true;
            canvas.removeEventListener('mousemove', canvasHover);
        }
        else if(X == 6 && Y == 8){
            slideFields(state, 5, -1, -1);
            hasMovedField = true;
            canvas.removeEventListener('mousemove', canvasHover);
        }
        else if(X == 0 && Y == 2){
            slideFields(state, -1, 1, 1);
            hasMovedField = true;
            canvas.removeEventListener('mousemove', canvasHover);
        }
        else if(X == 0 && Y == 4){
            slideFields(state, -1, 3, 1);
            hasMovedField = true;
            canvas.removeEventListener('mousemove', canvasHover);
        }
        else if(X == 0 && Y == 6){
            slideFields(state, -1, 5, 1);
            hasMovedField = true;
            canvas.removeEventListener('mousemove', canvasHover);
        }
    }
    else if(hasMovedField){
        movePlayer(state, state.currentPlayer, parseInt(X, 10) - 1, parseInt(Y, 10) - 1);
        console.log(state);
        setTimeout( function(){
            if(state.playerWon(state.currentPlayer)){
                playerWon.innerHTML = state.currentPlayer + 1 + ". játékos nyert!";
                gameOver.style.display = "block";
            }
            updateInfo();
        }, 100);
            
    }
 }, false);

function canvasHover(event){
    const rect = canvas.getBoundingClientRect();
    const elementRelativeX = event.clientX - rect.left;
    const elementRelativeY = event.clientY - rect.top;
    const canvasRelativeX = elementRelativeX * canvas.width / rect.width;
    const canvasRelativeY = elementRelativeY * canvas.height / rect.height;
    let X = parseInt(canvasRelativeX/50, 10);
    let Y = parseInt(canvasRelativeY/50, 10);
    let efX = parseInt(efCurrX/50, 10);
    let efY = parseInt(efCurrY/50, 10);
    if(X != efX || Y != efY){
        if(X == 2 && Y == 0 )
            moveExtraField(state, 100, 0);
        else if(X == 4 && Y == 0)
            moveExtraField(state, 200, 0);
        else if(X == 6 && Y == 0)
            moveExtraField(state, 300, 0);
        else if(X == 8 && Y == 2)
            moveExtraField(state, 400, 100);
        else if(X == 8 && Y == 4)
            moveExtraField(state, 400, 200);
        else if(X == 8 && Y == 6)
            moveExtraField(state, 400, 300);
        else if(X == 2 && Y == 8)
            moveExtraField(state, 100, 400);
        else if(X == 4 && Y == 8)
            moveExtraField(state, 200, 400);
        else if(X == 6 && Y == 8)
            moveExtraField(state, 300, 400)
        else if(X == 0 && Y == 2)
            moveExtraField(state, 0, 100);
        else if(X == 0 && Y == 4)
            moveExtraField(state, 0, 200);
        else if(X == 0 && Y == 6)
            moveExtraField(state, 0, 300);
        else
        moveExtraField(state, 500, 200);
    }
}

canvas.addEventListener('contextmenu', function(event){
    event.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const elementRelativeX = event.clientX - rect.left;
    const elementRelativeY = event.clientY - rect.top;
    const canvasRelativeX = elementRelativeX * canvas.width / rect.width;
    const canvasRelativeY = elementRelativeY * canvas.height / rect.height;
    let X = parseInt(canvasRelativeX/50, 10);
    let Y = parseInt(canvasRelativeY/50, 10);
    let efX = parseInt(efCurrX/50, 10);
    let efY = parseInt(efCurrY/50, 10);
    if(X == efX  && Y == efY){
        state.rotateExtraField();
        renderExtraField(state);
    }
}, false);