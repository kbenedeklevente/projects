﻿namespace ColorWarGame.Persistence
{
    public enum Colors
    {
        White,
        Red,
        Blue,
        LightRed,
        LightBlue,
        Temp
    }
}
