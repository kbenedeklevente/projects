﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ColorWarGame.Persistence
{
    public interface IColorWarDataAccess
    {
        Task<ColorWarBoard> LoadAsync(String path);

        Task SaveAsync(String path, ColorWarBoard board);
    }
}
