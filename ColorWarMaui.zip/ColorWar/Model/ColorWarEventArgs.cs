﻿using ColorWarGame.Persistence;
using System;

namespace ColorWarGame.Model
{
    public class ColorWarEventArgs : EventArgs
    {
        private Int32 _boardSize;
        private Colors _colorWon;
        private Int32 _blueArea;
        private Int32 _redArea;
        private Boolean _rotated;
        private Colors _turn;

        public Int32 BoardSize { get { return _boardSize; } }
        public Colors ColorWon { get { return _colorWon; } }
        public Int32 BlueArea { get { return _blueArea; } }
        public Int32 RedArea { get { return _redArea; } }
        public Boolean Rotated { get { return _rotated; } }
        public Colors Turn { get { return _turn; } }


        public ColorWarEventArgs(Int32 gameBoardSize, Colors colorWon, Int32 redArea, Int32 blueArea, Boolean rotated, Colors turn)
        {
            _boardSize = gameBoardSize;
            _colorWon = colorWon;
            _blueArea = blueArea;
            _redArea = redArea;
            _rotated = rotated;
            _turn = turn;
        }
    }
}