﻿using System;

namespace ColorWarGame.Model
{
    public class StoredGameModel
    {

        public String Name { get; set; } = String.Empty;

        public DateTime Modified { get; set; }
    }
}
