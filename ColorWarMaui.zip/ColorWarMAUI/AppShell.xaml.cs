﻿using ColorWarGame.Model;
using ColorWarGame.Persistence;
using ColorWarMAUI.ViewModel;
using ColorWarMAUI.View;

namespace ColorWarMAUI;

public partial class AppShell : Shell
{
    #region Fields

    private IColorWarDataAccess _colorWarDataAccess;
    private readonly ColorWarModel _colorWarModel;
    private readonly ColorWarViewModel _colorWarViewModel;

    private readonly IStore _store;
    private readonly StoredGameBrowserModel _storedGameBrowserModel;
    private readonly StoredGameBrowserViewModel _storedGameBrowserViewModel;

    #endregion

    #region Application methods

    public AppShell(IStore colorWarStore,
        IColorWarDataAccess colorWarDataAccess,
        ColorWarModel colorWarModel,
        ColorWarViewModel colorWarViewModel)
    {
        InitializeComponent();

        _store = colorWarStore;
        _colorWarDataAccess = colorWarDataAccess;
        _colorWarModel = colorWarModel;
        _colorWarViewModel = colorWarViewModel;

        _colorWarModel.GameOver += ColorWarModel_GameOver;

        _colorWarViewModel.NewGameSmall += ColorWarViewModel_NewGameSmall;
        _colorWarViewModel.NewGameMid += ColorWarViewModel_NewGameMid;
        _colorWarViewModel.NewGameBig += ColorWarViewModel_NewGameBig;
        _colorWarViewModel.LoadGame += ColorWarViewModel_LoadGame;
        _colorWarViewModel.SaveGame += ColorWarViewModel_SaveGame;
        _colorWarViewModel.ExitGame += ColorWarViewModel_ExitGame;
        _colorWarViewModel.Rotate += ColorWarViewModel_Rotate;


        _storedGameBrowserModel = new StoredGameBrowserModel(_store);
        _storedGameBrowserViewModel = new StoredGameBrowserViewModel(_storedGameBrowserModel);
        _storedGameBrowserViewModel.GameLoading += StoredGameBrowserViewModel_GameLoading;
        _storedGameBrowserViewModel.GameSaving += StoredGameBrowserViewModel_GameSaving;
    }

    #endregion

    #region Model event handlers

    private async void ColorWarModel_GameOver(object? sender, ColorWarEventArgs e)
    { 

        if ((int)e.ColorWon == 1)
        {
            await DisplayAlert("Color war",
                "Red player won!" + Environment.NewLine +
                "Colored " + e.RedArea + " blocks while blue colored " + e.BlueArea + " blocks.",
                "OK");
        }
        else if ((int)e.ColorWon == 2)
        {
            await DisplayAlert("Color war",
                "Blue player won!" + Environment.NewLine +
                "Colored " + e.BlueArea + " blocks while red colored " + e.RedArea + " blocks.",
                "OK");
        }
        else if ((int)e.ColorWon == 5)
        {
            await DisplayAlert("Color war",
                "Draw!" + Environment.NewLine +
                "Blue colored " + e.BlueArea + " blocks while red colored " + e.RedArea + " blocks.",
                "OK");
        }
        _colorWarModel.NewGame(6);
    }

    #endregion

    #region ViewModel event handlers

    private void ColorWarViewModel_NewGameSmall(object? sender, EventArgs e)
    {
        _colorWarModel.NewGame(6);
    }

    private void ColorWarViewModel_NewGameMid(object? sender, EventArgs e)
    {
        _colorWarModel.NewGame(8);
    }

    private void ColorWarViewModel_NewGameBig(object? sender, EventArgs e)
    {
        _colorWarModel.NewGame(10);
    }

    private async void ColorWarViewModel_LoadGame(object? sender, EventArgs e)
    {
        await _storedGameBrowserModel.UpdateAsync();
        await Navigation.PushAsync(new LoadGamePage
        {
            BindingContext = _storedGameBrowserViewModel
        });
    }

    private async void ColorWarViewModel_SaveGame(object? sender, EventArgs e)
    {
        await _storedGameBrowserModel.UpdateAsync();
        await Navigation.PushAsync(new SaveGamePage
        {
            BindingContext = _storedGameBrowserViewModel
        });
    }

    private async void ColorWarViewModel_ExitGame(object? sender, EventArgs e)
    {
        await Navigation.PushAsync(new SettingsPage
        {
            BindingContext = _colorWarViewModel
        });
    }

    private void ColorWarViewModel_Rotate(object? sender, EventArgs e)
    {
        _colorWarModel.Rotate();
    }

    private async void StoredGameBrowserViewModel_GameLoading(object? sender, StoredGameEventArgs e)
    {
        await Navigation.PopAsync();

        try
        {
            await _colorWarModel.LoadGameAsync(e.Name);

            await Navigation.PopAsync();
            await DisplayAlert("Color War", "Load successfull", "OK");

        }
        catch
        {
            await DisplayAlert("Color War", "Load failed", "OK");
        }
    }

    private async void StoredGameBrowserViewModel_GameSaving(object? sender, StoredGameEventArgs e)
    {
        await Navigation.PopAsync();

        try
        {
            await _colorWarModel.SaveGameAsync(e.Name);
            await DisplayAlert("Color War", "Save successfull", "OK");
        }
        catch
        {
            await DisplayAlert("Color War", "Save failed", "OK");
        }
    }

    #endregion
}