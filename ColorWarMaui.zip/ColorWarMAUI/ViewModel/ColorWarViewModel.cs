﻿using System;
using System.Collections.ObjectModel;
using ColorWarGame.Model;
using ColorWarMAUI.ViewModel;

namespace ColorWarMAUI.ViewModel
{
    public class ColorWarViewModel : ViewModelBase
    {

        #region Fields

        private ColorWarModel _model;

        #endregion

        #region Properties

        public DelegateCommand RotateCommand { get; private set; }

        public DelegateCommand LoadGameCommand { get; private set; }

        public DelegateCommand SaveGameCommand { get; private set; }

        public DelegateCommand NewGameSmallCommand { get; private set; }

        public DelegateCommand NewGameMidCommand { get; private set; }

        public DelegateCommand NewGameBigCommand { get; private set; }

        public DelegateCommand ExitCommand { get; private set; }

        public ObservableCollection<ColorWarField> Fields { get; set; } = null!;

        public RowDefinitionCollection GameBoardRows
        {
            get => new RowDefinitionCollection(Enumerable.Repeat(new RowDefinition(GridLength.Star), BoardSize).ToArray());
        }

        public ColumnDefinitionCollection GameBoardColumns
        {
            get => new ColumnDefinitionCollection(Enumerable.Repeat(new ColumnDefinition(GridLength.Star), BoardSize).ToArray());
        }

        public Int32 BlueArea { get { return _model.BlueArea; } }

        public Int32 RedArea { get { return _model.RedArea; } }

        public Int32 BoardSize { get { return _model.BoardSize; } }

        public String Rotation
        {
            get
            {
                if (_model.Rotated) return "Vertical";
                else return "Horizontal";
            }
        }

        public String Turn
        {
            get
            {
                if ((Int32)_model.Turn == 2) return "Blue";
                else return "Red";
            }
        }


        #endregion

        #region Events

        public event EventHandler? Rotate;

        public event EventHandler? NewGameSmall;

        public event EventHandler? NewGameMid;

        public event EventHandler? NewGameBig;

        public event EventHandler? LoadGame;

        public event EventHandler? SaveGame;

        public event EventHandler? ExitGame;



        #endregion

        #region Constructors

        public ColorWarViewModel(ColorWarModel model)
        {

            _model = model;
            _model.GameOver += new EventHandler<ColorWarEventArgs>(Model_GameOver);
            _model.StateChanged += new EventHandler<ColorWarEventArgs>(Model_StateChanged);

            RotateCommand = new DelegateCommand(param => OnRotate());

            NewGameSmallCommand = new DelegateCommand(param => OnNewGameSmall());
            NewGameMidCommand = new DelegateCommand(param => OnNewGameMid());
            NewGameBigCommand = new DelegateCommand(param => OnNewGameBig());
            LoadGameCommand = new DelegateCommand(param => OnLoadGame());
            SaveGameCommand = new DelegateCommand(param => OnSaveGame());
            ExitCommand = new DelegateCommand(param => OnExitGame());

            GenerateTable();

            RefreshTable();
        }

        #endregion

        #region Private methods

        private void GenerateTable()
        {
            Fields = new ObservableCollection<ColorWarField>();
            for (Int32 i = 0; i < _model.BoardSize; i++)
            {
                for (Int32 j = 0; j < _model.BoardSize; j++)
                {
                    Fields.Add(new ColorWarField
                    {
                        IsLocked = false,
                        Color = 0,
                        X = i,
                        Y = j,
                        Number = i * _model.BoardSize + j,
                        StepCommand = new DelegateCommand(param => StepGame(Convert.ToInt32(param)))
                    }); ;
                }
            }
        }

        private void RefreshTable()
        {
            foreach (ColorWarField field in Fields)
            {
                field.Color = (Int32)_model.Board[field.X, field.Y];
                field.IsLocked = _model.Board.FieldLocked(field.X, field.Y);
                field.IsEnabled = !_model.Board.FieldLocked(field.X, field.Y);
            }
            OnPropertyChanged(nameof(Fields));

        }

        private void StepGame(Int32 index)
        {
            ColorWarField field = Fields[index];

            _model.PlayerTurn(field.X, field.Y);

            field.Color = (Int32)_model.Board[field.X, field.Y];

            RefreshTable();

            OnPropertyChanged(nameof(BlueArea));
            OnPropertyChanged(nameof(RedArea));
        }

        #endregion

        #region Game event handlers

        private void Model_GameOver(object? sender, ColorWarEventArgs e)
        {
            foreach (ColorWarField field in Fields)
            {
                field.IsLocked = true;
            }
            RefreshTable();
            OnPropertyChanged(nameof(Fields));
        }

        private void Model_StateChanged(object? sender, ColorWarEventArgs e)
        {
            GenerateTable();
            RefreshTable();
            OnPropertyChanged(nameof(Fields));
            OnPropertyChanged(nameof(BoardSize));
            OnPropertyChanged(nameof(GameBoardRows));
            OnPropertyChanged(nameof(GameBoardColumns));
            OnPropertyChanged(nameof(Turn));
            OnPropertyChanged(nameof(BlueArea));
            OnPropertyChanged(nameof(RedArea));
            OnPropertyChanged(nameof(Rotation));
        }

        #endregion

        #region Event methods

        private void OnRotate()
        {
            Rotate?.Invoke(this, EventArgs.Empty);

            OnPropertyChanged(nameof(Rotation));
        }

        private void OnNewGameSmall()
        {
            NewGameSmall?.Invoke(this, EventArgs.Empty);

            OnPropertyChanged(nameof(BoardSize));
            OnPropertyChanged(nameof(GameBoardRows));
            OnPropertyChanged(nameof(GameBoardColumns));
        }


        private void OnNewGameMid()
        {
            NewGameMid?.Invoke(this, EventArgs.Empty);

            OnPropertyChanged(nameof(BoardSize));
            OnPropertyChanged(nameof(GameBoardRows));
            OnPropertyChanged(nameof(GameBoardColumns));
        }


        private void OnNewGameBig()
        {
            NewGameBig?.Invoke(this, EventArgs.Empty);

            OnPropertyChanged(nameof(BoardSize));
            OnPropertyChanged(nameof(GameBoardRows));
            OnPropertyChanged(nameof(GameBoardColumns));
        }

        private void OnLoadGame()
        {
            LoadGame?.Invoke(this, EventArgs.Empty);

        }

        private void OnSaveGame()
        {
            SaveGame?.Invoke(this, EventArgs.Empty);
        }

        private void OnExitGame()
        {
            ExitGame?.Invoke(this, EventArgs.Empty);
        }

        #endregion
    }
}
