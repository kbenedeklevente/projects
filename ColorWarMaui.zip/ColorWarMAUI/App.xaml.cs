﻿using ColorWarGame.Persistence;
using ColorWarMAUI.ViewModel;
using ColorWarGame.Model;
using ColorWarMAUI.View;

namespace ColorWarMAUI;

public partial class App : Application
{

    private const string SuspendedGameSavePath = "SuspendedGame";

    private readonly AppShell _appShell;
    private readonly IColorWarDataAccess _colorWarDataAccess;
    private readonly ColorWarModel _colorWarModel;
    private readonly IStore _colorWarStore;
    private readonly ColorWarViewModel _colorWarViewModel;

    public App()
    {
        InitializeComponent();

        _colorWarStore = new ColorWarStore();
        _colorWarDataAccess = new ColorWarFileDataAccess(FileSystem.AppDataDirectory);

        _colorWarModel = new ColorWarModel(6, _colorWarDataAccess);
        _colorWarViewModel = new ColorWarViewModel(_colorWarModel);

        _appShell = new AppShell(_colorWarStore, _colorWarDataAccess, _colorWarModel, _colorWarViewModel)
        {
            BindingContext = _colorWarViewModel
        };
        MainPage = _appShell;
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        Window window = base.CreateWindow(activationState);

        window.Created += (s, e) =>
        {
            _colorWarModel.NewGame(6);
        };

        window.Activated += (s, e) =>
        {
            if (!File.Exists(Path.Combine(FileSystem.AppDataDirectory, SuspendedGameSavePath)))
                return;

            Task.Run(async () =>
            {
                try
                {
                    await _colorWarModel.LoadGameAsync(SuspendedGameSavePath);
                }
                catch
                {
                }
            });
        };

        window.Stopped += (s, e) =>
        {
            Task.Run(async () =>
            {
                try
                {
                    await _colorWarModel.SaveGameAsync(SuspendedGameSavePath);
                }
                catch
                {
                }
            });
        };

        return window;
    }
}