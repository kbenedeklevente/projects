namespace ColorWarMAUI.View;

public partial class SaveGamePage : ContentPage
{
	public SaveGamePage()
	{
		InitializeComponent();
	}
}