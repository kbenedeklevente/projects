namespace ColorWarMAUI.View;

public partial class GamePage : ContentPage
{
	public GamePage()
	{
		InitializeComponent();
	}
}